# Historische TIDE-0.5-Referenz

Dieses Verzeichnis hält den früheren Interpreter, die interaktiven Hosts und ihre Integrationstests als unabhängige Vergleichsbasis fest. Das aktuelle Werkzeug wird aus dem Projektstamm mit Make gebaut. Die Verknüpfung `apps` erlaubt den historischen Tests, dieselben TIDE-Anwendungsquellen zu lesen.

```sh
cd experimente/referenzsystem
./reference-tide test apps/report.tide
python3 -m unittest discover -s tests -v
```

Der Starter `tide` in diesem Verzeichnis dient ausschließlich den archivierten Tests. Für einen Differentialvergleich aus dem Projektstamm kann `./experimente/referenzsystem/reference-tide` ausdrücklich aufgerufen werden.
