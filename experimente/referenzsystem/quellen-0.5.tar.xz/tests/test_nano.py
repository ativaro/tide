"""Test the TIDE editor, its document grant, and the interactive CLI together."""

import fcntl
import os
import pty
import select
import struct
import subprocess
import tempfile
import termios
import time
import unittest
from pathlib import Path

from tide_lang.core import Error
from tide_lang.document import Document, clipped
from tide_lang.program import compile_source
from tide_lang.runtime import Run
from tide_lang.workbench import project

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "apps/nano.tide"


class NanoTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.defs, _ = compile_source(*project(APP))

    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.path = Path(temp.name) / "notizen.txt"

    def call(self, function, **env):
        return Run(self.defs).eval(self.defs[function].body, env)

    def test_cursor_edits_and_clipboard(self):
        body = "eins\r\nö\n三12"
        world = self.call("main", body=body)

        def key(kind, value=""):
            nonlocal world
            world, effect = self.call("step", world=world, key=kind, value=value)
            self.assertEqual(effect, "idle")

        key("end_key")
        key("down")
        self.assertEqual(world["caret"], 7)
        key("down")
        self.assertEqual(world["caret"], len(body))
        key("up")
        key("control", "k")
        self.assertEqual((world["body"], world["clip"]), ("eins\r\n三12", "ö\n"))
        key("control", "u")
        self.assertEqual(world["body"], body)
        key("backspace")
        self.assertEqual(world["body"], "eins\r\nö三12")
        key("home_key")
        key("left")
        self.assertEqual(world["caret"], 4)
        key("delete_key")
        self.assertEqual(world["body"], "einsö三12")
        key("enter_key")
        self.assertEqual(world["body"], "eins\r\nö三12")

    def test_file_preservation(self):
        self.path.write_bytes(b"original\n")
        self.path.chmod(0o640)
        first, other = Document(self.path), Document(self.path)
        first.save("changed")
        self.assertEqual(self.path.stat().st_mode & 0o777, 0o640)
        with self.assertRaisesRegex(Error, "extern"):
            other.save("stale")
        self.assertEqual(self.path.read_bytes(), b"changed")
        self.path.unlink()
        new = Document(self.path)
        self.path.write_bytes(b"new owner")
        with self.assertRaisesRegex(Error, "extern"):
            new.save("stale")
        self.assertEqual(self.path.read_bytes(), b"new owner")
        self.path.write_bytes(b"\xff")
        with self.assertRaises(Error) as bad:
            Document(self.path)
        self.assertEqual(bad.exception.code, "E_UTF8")

    def test_visible_text(self):
        self.assertEqual(clipped("ä\t界x", 0, 8), "ä   界x")
        self.assertEqual(clipped("ä\t界x", 5, 2), " x")
        self.assertEqual(clipped("a\x1bb", 0, 9), "a?b")

    def terminal(self):
        master, slave = pty.openpty()
        self.addCleanup(os.close, master)
        self.addCleanup(os.close, slave)
        fcntl.ioctl(slave, termios.TIOCSWINSZ, struct.pack("HHHH", 16, 78, 0, 0))
        proc = subprocess.Popen(
            [ROOT / "tide", "play", APP, "--document", self.path],
            stdin=slave,
            stdout=slave,
            stderr=slave,
            env={**os.environ, "TERM": "xterm-256color", "LC_ALL": "C.UTF-8"},
        )

        def cleanup():
            if proc.poll() is None:
                proc.kill()
            proc.wait()

        self.addCleanup(cleanup)

        def wait_for(word):
            data = bytearray()
            deadline = time.monotonic() + 5
            while word not in data:
                remaining = deadline - time.monotonic()
                self.assertGreater(remaining, 0, repr(data[-500:]))
                if select.select([master], [], [], remaining)[0]:
                    data.extend(os.read(master, 8192))

        wait_for(b"TIDE nano")
        return proc, lambda data: os.write(master, data), wait_for

    def test_create_save_reopen_and_discard(self):
        proc, send, wait_for = self.terminal()
        self.assertFalse(self.path.exists())
        send("Grüße\rzwei".encode() + b"\x0f")
        wait_for(b"Gespeichert")
        send(b"\x18")
        self.assertEqual(proc.wait(timeout=3), 0)
        saved = "Grüße\nzwei".encode()
        self.assertEqual(self.path.read_bytes(), saved)
        proc, send, wait_for = self.terminal()
        send(b"\x1bOB\x1bOF!\x18")  # Down, End, insert, Ctrl+X
        wait_for(b"Verwerfen")
        send(b"\x03?\x18n")  # Cancel, continue typing, discard
        self.assertEqual(proc.wait(timeout=3), 0)
        self.assertEqual(self.path.read_bytes(), saved)
        proc, send, wait_for = self.terminal()
        send(b"\x1bOB\x1bOF!\x18")
        wait_for(b"Verwerfen")
        send(b"j")
        self.assertEqual(proc.wait(timeout=3), 0)
        self.assertEqual(self.path.read_bytes(), saved + b"!")

    def test_failed_save_keeps_session(self):
        self.path.write_text("a")
        proc, send, wait_for = self.terminal()
        self.path.write_text("extern")
        send(b"b\x18j")
        wait_for(b"extern")
        self.assertIsNone(proc.poll())
        send(b"\x18n")
        self.assertEqual(proc.wait(timeout=3), 0)
        self.assertEqual(self.path.read_text(), "extern")

    def test_scroll_and_preserve_crlf(self):
        body = ("ö\r\n" * 20 + "x" * 100).encode()
        self.path.write_bytes(body)
        proc, send, wait_for = self.terminal()
        send(b"\x1bOB" * 20 + b"\x1bOF!\rZ\x0f")
        wait_for(b"Gespeichert")
        send(b"\x18")
        self.assertEqual(proc.wait(timeout=3), 0)
        self.assertEqual(self.path.read_bytes(), body + b"!\r\nZ")
