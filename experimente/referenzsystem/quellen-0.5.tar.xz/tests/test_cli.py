"""Integration tests using the same executable as the sample apps."""

import json
import subprocess
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class CommandTests(unittest.TestCase):
    def command(self, action, path, *flags, error=None):
        proc = subprocess.run(
            [ROOT / "tide", action, path, *flags],
            cwd=path.parent,
            check=False,
            capture_output=True,
            text=True,
            timeout=8,
        )
        if error is None:
            self.assertEqual(proc.returncode, 0, proc.stderr)
            self.assertEqual(proc.stderr, "")
            return json.loads(proc.stdout)
        self.assertEqual(proc.returncode, 1, proc.stderr)
        self.assertEqual(proc.stdout, "")
        detail = json.loads(proc.stderr)
        self.assertEqual(detail["code"], error, detail)
        return detail

    def snippet(self, text, action="run", *flags, error=None):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "case.tide"
            path.write_text(text, encoding="utf-8")
            return self.command(action, path, *flags, error=error)

    def test_applications(self):
        cases = {
            "light": (3, [False, True, True, False, True, True]),
            "heat": (3, [False, False, False, False, True, True, False]),
            "pump": (2, [False, True, True, True, False, False]),
            "balance": (3, 97),
        }
        for name, (examples, want) in cases.items():
            with self.subTest(name=name):
                path = ROOT / "apps" / (name + ".tide")
                self.assertEqual(self.command("check", path)["examples"], examples)
                self.assertEqual(self.command("test", path), {"passed": examples})
                self.assertEqual(self.command("run", path), want)

    def test_runtime_inputs(self):
        path = ROOT / "apps/light.tide"
        self.assertEqual(
            self.command(
                "run",
                path,
                "--call",
                "simulate",
                "--inputs",
                '{"events":[true,false,false]}',
            ),
            [True, True, False],
        )
        for bad in ('{"events":[1]}', "{}", '{"events":[], "unused":0}'):
            self.command(
                "run", path, "--call", "simulate", "--inputs", bad, error="E_INPUT"
            )
        self.command(
            "run",
            path,
            "--call",
            "simulate",
            "--inputs",
            '{"events":[],"events":[]}',
            error="E_JSON",
        )

    def test_refuse_before_run(self):
        cases = [
            ("main > i\n+ 1 true", "E_TYPE"),
            ("main > i\n+ 1", "E_SYNTAX"),
            ("main > i\n1 2", "E_SYNTAX"),
            ("main > i\n(+ 1 2", "E_SYNTAX"),
            ("main > i\nif false typo 0", "E_NAME"),
            ("main > i\n1\n\nbad > i\nother\n\nother > i\nbad", "E_CYCLE"),
            ("main > i\ncatch E_LIMIT 1 _ 2", "E_TYPE"),
            ("main > i\n9223372036854775808", "E_RANGE"),
            ("main > i\nlet x 1 let x 2 x", "E_NAME"),
        ]
        for text, err in cases:
            with self.subTest(text=text):
                detail = self.snippet(text, "check", error=err)
                self.assertGreaterEqual(detail["line"], 1)
                self.assertGreaterEqual(detail["column"], 1)

    def test_lazy_and_checked_arithmetic(self):
        for expr, want in [
            ("if false + 9223372036854775807 1 0", 0),
            ("catch E_OVERFLOW + -9223372036854775808 -1 _ 5", 5),
            ('catch E_DATA fail "bad value" _ 9', 9),
        ]:
            self.assertEqual(self.snippet("main > i\n" + expr), want)
        self.snippet(
            "main > i\ncatch E_DATA + 9223372036854775807 1 _ 0", error="E_OVERFLOW"
        )

    def test_positions_in_fold(self):
        self.assertEqual(
            self.snippet(
                "main > i\nfold list b 3 true false true 0 acc pos item "
                "if item + acc pos acc"
            ),
            4,
        )

    def test_all_state_reads_are_old_until_out(self):
        rule = (
            "rule swap go:b > &ii\nstate a:i=1 b:i=2\n"
            "when go -> b=set a, a=set b\nelse -> b=reset, a=reset\nout pair a b\n\n"
        )
        self.assertEqual(
            self.snippet(rule + "main > *&ii\nscan swap list b 3 true true false"),
            [[2, 1], [1, 2], [1, 2]],
        )
        self.snippet(
            rule.replace("b=set a, a=set b", "b=set a") + "main > b\ntrue",
            "check",
            error="E_TYPE",
        )
        self.snippet(
            rule.replace("b=set a, a=set b", "b=set a, b=set a") + "main > b\ntrue",
            "check",
            error="E_NAME",
        )

    def test_example_regression(self):
        text = (
            "rule active event:b > b\nstate on:b=false\nelse -> on=set event\nout on\n\n"
            'example probe active\n{"events":[true,false],"expect":[true,true]}'
        )
        detail = self.snippet(text, "test", error="E_EXAMPLE")
        self.assertEqual(
            (detail["event"], detail["expected"], detail["actual"]), (2, True, False)
        )

    def test_limits(self):
        program = (
            "main xs:*i > i\ncatch E_OVERFLOW fold xs 0 a p x fold xs a b q y + b y _ 0"
        )
        self.snippet(
            program, "run", "--inputs", json.dumps({"xs": [0] * 200}), error="E_LIMIT"
        )
        self.snippet("main > *i\nlist i 4097", "check", error="E_LIMIT")
        self.snippet("main > i\n" + "+ 0 " * 49 + "1", "check", error="E_LIMIT")
        self.snippet("main > i\n1" + " " * 131072, "check", error="E_LIMIT")


if __name__ == "__main__":
    unittest.main()
