"""End-to-end language and model-tool contracts, including failing programs."""

import concurrent.futures
import json
import subprocess
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class LanguageTests(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.dir = Path(temp.name)
        self.src = self.dir / "main.tide"

    def cli(self, *args, error=None, raw=False):
        proc = subprocess.run(
            [ROOT / "tide", *map(str, args)],
            cwd=self.dir,
            capture_output=True,
            check=False,
            timeout=10,
            text=True,
        )
        if error is not None:
            self.assertEqual((proc.returncode, proc.stdout), (1, ""), proc.stderr)
            result = json.loads(proc.stderr)
            self.assertEqual(result["code"], error, result)
            return result
        self.assertEqual((proc.returncode, proc.stderr), (0, ""), proc.stderr)
        return proc.stdout if raw else json.loads(proc.stdout)

    def program(self, text):
        self.src.write_text(text)
        return self.src

    def test_granted_file_and_positions(self):
        values = self.dir / "data.txt"
        peak = ROOT / "apps/first_peak.tide"
        for content, expected in [
            (b"", {"none": True}),
            (b"-8\r\n-2\r\n-2\r\n", {"some": [-2, 2]}),
            (b"0", {"some": [0, 1]}),
        ]:
            values.write_bytes(content)
            self.assertEqual(
                self.cli("run", peak, "--read", f"input={values}"), expected
            )
        values.write_bytes(b"4\n\n7")
        detail = self.cli("run", peak, "--read", f"input={values}", error="E_DATA")
        self.assertEqual(
            (detail["input_line"], detail["reason"], detail["line"]),
            (2, "invalid_integer", 3),
        )
        values.write_bytes(b"\xff")
        self.cli("run", peak, "--read", f"input={values}", error="E_UTF8")
        self.cli("run", peak, "--inputs", '{"input":"data.txt"}', error="E_CAPABILITY")
        self.cli("run", peak, "--read", "input=.", error="E_CAPABILITY")
        self.cli("run", peak, "--read", "extra=missing", error="E_CAPABILITY")
        self.cli(
            "run",
            self.program("main x:r > i\nunknown"),
            "--read",
            "x=missing",
            error="E_NAME",
        )

    def test_checked_operations_and_bounds(self):
        for typ, expr, want in [
            ("&ii", "pair div -7 2 mod -7 2", [-3, -1]),
            ("&ii", "pair div 7 -2 mod 7 -2", [-3, 1]),
            ("?i", 'int "-9223372036854775808"', {"some": -(2**63)}),
            ("?i", 'int "9223372036854775808"', {"none": True}),
            ("?i", 'int "+2"', {"none": True}),
            ("b", 'and false fail "skip"', False),
            ("b", 'or true fail "skip"', True),
            ("?&it", 'at append list &it 0 pair 1 "ok" 0', {"some": [1, "ok"]}),
            ("*t", 'lines "a\\r\\nb\\rX\\n\\n"', ["a", "b\rX", ""]),
            ("t", 'need some concat "a" "b" fail "skip" fail "skip"', "ab"),
            ("i", 'catch E_DATA div 1 0 e if has_reason e "division_by_zero" 2 3', 2),
        ]:
            with self.subTest(expr=expr):
                self.assertEqual(
                    self.cli("run", self.program(f"main > {typ}\n{expr}")), want
                )
        for expr in (
            "* 9223372036854775807 2",
            "div -9223372036854775808 -1",
            "- -9223372036854775808 1",
        ):
            self.cli("run", self.program("main > i\n" + expr), error="E_OVERFLOW")

    def test_named_handler_and_effects(self):
        src = self.program(
            'parse text:t > i\nneed int text "bad_integer" 4\n\n'
            'main text:t > i\ncatch E_DATA parse text e if has_reason e "bad_integer" case input_line e -1 n n raise e'
        )
        self.assertEqual(self.cli("run", src, "--inputs", '{"text":"bad"}'), 4)
        self.assertEqual(self.cli("run", src, "--inputs", '{"text":"8"}'), 8)
        chk = self.cli("check", src)["definitions"]
        self.assertEqual(chk["main"]["may_fail"], ["E_DATA"])
        self.program(self.src.read_text().replace('"bad_integer" case', '"other" case'))
        e = self.cli("run", src, "--inputs", '{"text":"?"}', error="E_DATA")
        self.assertEqual(
            (e["reason"], e["line"], e["column"], e["input_line"]),
            ("bad_integer", 2, 1, 4),
        )
        self.cli("check", self.program("main > ?i\ninput_line nowhere"), error="E_TYPE")
        self.cli("check", self.program("main x:r > &ir\npair 2 x"), error="E_SYNTAX")
        self.cli(
            "check",
            self.program("main x:r > *i\nlet unused some x list i 0"),
            error="E_TYPE",
        )
        self.cli(
            "check",
            self.program(
                'helper x:r > t\nread x\n\nrule bad x:i > t\nstate s:i=0\nelse -> s=keep\nout helper fail "missing"'
            ),
            error="E_CAPABILITY",
        )
        checked = self.cli(
            "check",
            self.program("safe a:i b:i > ?i\ncatch E_OVERFLOW some + a b _ nil i"),
        )
        self.assertEqual(checked["definitions"]["safe"]["may_fail"], [])

    def test_guest_budgets(self):
        data = self.dir / "data"
        data.write_bytes(b"a" * 131072)
        self.program("main input:r > i\nlength lines read input")
        self.assertEqual(self.cli("run", self.src, "--read", f"input={data}"), 1)
        data.write_bytes(b"a" * 131073)
        self.cli("run", self.src, "--read", f"input={data}", error="E_LIMIT")
        self.cli("run", self.program("main > *i\nlist i 4096 " + "0 " * 4096))
        self.cli("check", self.program("main > *i\nlist i 4097"), error="E_LIMIT")
        self.program(
            "main input:r > t\nlet line read input\nfold list i 6 0 0 0 0 0 0 line acc row x concat acc acc"
        )
        data.write_bytes(b"a" * 32768)
        self.cli("run", self.src, "--read", f"input={data}", error="E_LIMIT")

    def test_records_and_modules(self):
        helper = self.dir / "values.tide"
        helper.write_text("record Point\nx:i y:i\n\ncoord p:{Point} > i\nget x p")
        self.program(
            "use values\n\nmain p:{Point} > ?{Point}\nsome with x p + coord p 1"
        )
        inp = ["--inputs", '{"p":{"x":4,"y":2}}']
        self.assertEqual(self.cli("run", self.src, *inp), {"some": {"x": 5, "y": 2}})
        self.cli("run", self.src, "--inputs", '{"p":{"x":true,"y":2}}', error="E_INPUT")
        self.cli(
            "check",
            self.program("use values\n\nmain > {Point}\nmake Point y 2 x 1"),
            error="E_FIELD",
        )
        self.cli(
            "check",
            self.program("record Loop\nnext:?{Loop}\n\nmain > i\n1"),
            error="E_TYPE",
        )
        self.cli(
            "check", self.program("main > ?{Unknown}\nnil {Unknown}"), error="E_TYPE"
        )
        self.program("use values\n\nmain > i\n1")
        helper.write_text("use main\n\nx > i\n0")
        self.cli("check", self.src, error="E_CYCLE")
        helper.unlink()
        helper.symlink_to(ROOT / "apps/balance.tide")
        self.cli("check", self.src, error="E_IO")

    def test_module_edits_and_revision(self):
        helper = self.dir / "ops.tide"
        helper.write_text("adjust x:i > i\n+ x 2")
        self.program(
            'use ops\n\nmain > i\nadjust 3\n\nexample ok main\n{"inputs":{},"expect":5}'
        )
        ctx = self.cli(
            "context", self.src, "--function", "adjust", "--node", "ops.tide:2:1"
        )
        self.assertEqual(ctx["affected_callers"], ["main"])
        self.assertEqual(ctx["selection"]["expanded"], "(+ x 2)")
        edit = ["edit", self.src, "--base", ctx["revision"], "--write", "--edits"]
        before = helper.read_bytes()
        self.cli(*edit, '[{"node":"ops.tide:2:1","op":"-"}]', error="E_EXAMPLE")
        self.assertEqual(helper.read_bytes(), before)
        ok = self.cli(*edit, '[{"node":"ops.tide:2:1","replace":"+ 2 x"}]')
        self.assertTrue(ok["written"])
        self.assertEqual(helper.read_text(), "adjust x:i > i\n+ 2 x")
        self.cli(*edit, '[{"node":"ops.tide:2:1","op":"-"}]', error="E_REVISION")
        self.assertEqual(self.cli("test", self.src), {"passed": 1})

    def test_contract_changes_and_preview(self):
        base = 'main > i\n+ 2 1\n\nexample ok main\n{"inputs":{},"expect":3}'
        self.program(base)
        other = self.dir / "candidate"
        other.write_text(
            base.replace("+ 2 1", "+ 3 1").replace('expect":3', 'expect":4')
        )
        rev = self.cli("check", self.src)["revision"]
        edit = ["edit", self.src, "--base", rev, "--source", other]
        self.cli(*edit, "--write", error="E_CONTRACT")
        preview = self.cli(*edit, "--change-examples")
        self.assertEqual(preview["contract_changes"][0]["before"]["expect"], 3)
        self.assertEqual(self.src.read_text(), base)
        self.cli(*edit, "--change-examples", "--write")
        self.assertEqual(self.cli("run", self.src), 4)

    def test_concurrent_writers(self):
        self.program("main > i\n5")
        base = self.cli("check", self.src)["revision"]

        def change(v):
            return subprocess.run(
                [
                    ROOT / "tide",
                    "edit",
                    self.src,
                    "--base",
                    base,
                    "--write",
                    "--edits",
                    json.dumps([{"node": "2:1", "replace": str(v)}]),
                ],
                capture_output=True,
                text=True,
                check=False,
            )

        with concurrent.futures.ThreadPoolExecutor(2) as pool:
            first, second = pool.map(change, [6, 7])
        self.assertEqual(sorted([first.returncode, second.returncode]), [0, 1])
        loser = first if first.returncode else second
        self.assertEqual(json.loads(loser.stderr)["code"], "E_REVISION")
        self.assertIn(self.cli("run", self.src), (6, 7))

    def test_trace_format_and_version(self):
        light = ROOT / "apps/light.tide"
        self.assertEqual(
            self.cli(
                "trace",
                light,
                "--example",
                "two_misses",
                "--step",
                "2",
                "--fields",
                "missed",
            )["fields"],
            {"missed": {"before": 1, "action": "reset", "after": 0}},
        )
        self.program(
            'main > t\n  concat   "a, = ("   " b"\n\nexample ok main\n{"inputs": {}, "expect": "a, = ( b"}'
        )
        formatted = self.cli("fmt", self.src, raw=True)
        self.program(formatted)
        self.assertEqual(self.cli("fmt", self.src, raw=True), formatted)
        self.assertEqual(self.cli("test", self.src), {"passed": 1})
        lock = self.cli("lock")
        (self.dir / "tide.lock").write_text(json.dumps(lock))
        self.assertEqual(self.cli("check", self.src)["version"], lock)
        self.assertEqual(
            self.cli("describe", "need", "--project", self.src)["catalog_sha256"],
            lock["catalog_sha256"],
        )
        (self.dir / "tide.lock").write_text(json.dumps({**lock, "language": "unknown"}))
        self.cli("run", self.src, error="E_VERSION")
        self.cli("describe", "need", "--project", self.src, error="E_VERSION")

    def test_variant_values_and_matching(self):
        types = "variant Signal\nred green\n\nvariant Lamp\nred green\n\nrecord Sample\nlights:*?{Signal}\n\n"
        self.program(
            types
            + 'main v:{Sample} > i\ncase at get lights v 0 0 light case light 0 s match s red fail "stop" green 7 end'
        )
        for value, expected in [
            ("green", 7),
            ("red", "E_DATA"),
            ("blue", "E_INPUT"),
            ({}, "E_INPUT"),
        ]:
            args = json.dumps({"v": {"lights": [{"some": value}]}})
            if type(expected) is int:
                self.assertEqual(self.cli("run", self.src, "--inputs", args), expected)
            else:
                self.cli("run", self.src, "--inputs", args, error=expected)
        for typ, body, code in [
            ("b", 'text_eq tag Signal red "red"', "E_TYPE"),
            ("{Signal}", "if true tag Signal red tag Lamp red", "E_TYPE"),
            ("{Signal}", '"red"', "E_TYPE"),
            ("{Signal}", "tag Signal blue", "E_TAG"),
            ("i", "match tag Signal red red 1 red 2 end", "E_TAG"),
            ("i", "match tag Signal red red 1 blue 2 end", "E_TAG"),
            ("i", "match tag Signal red red 1 green true end", "E_TYPE"),
            ("i", "match tag Signal red red 1 green 2", "E_SYNTAX"),
            ("i", 'match "red" red 1 green 2 end', "E_TYPE"),
        ]:
            with self.subTest(body=body):
                self.cli(
                    "check", self.program(types + f"main > {typ}\n" + body), error=code
                )
        self.cli("check", self.program("variant Lamp\non on"), error="E_NAME")
        self.cli("check", self.program(types + "record Lamp\nbulb:i"), error="E_NAME")

    def test_match_coverage_and_tooling(self):
        (self.dir / "lamp.tide").write_text(
            "variant Lamp\non off dim\n\nlevel x:{Lamp} > i\nmatch x on 2 off 0 end"
        )
        self.program(
            "use lamp\n\nmain v:{Lamp} > i\nmatch v on (match v dim 1 end) dim level v end"
        )
        issues = self.cli("check", self.src, error="E_MATCH")["diagnostics"]
        self.assertEqual(
            {
                (
                    Path(d["file"]).name,
                    d["definition"],
                    d["line"],
                    d["column"],
                    tuple(d["missing"]),
                )
                for d in issues
            },
            {
                ("lamp.tide", "level", 5, 1, ("dim",)),
                ("main.tide", "main", 4, 13, ("off", "on")),
                ("main.tide", "main", 4, 1, ("off",)),
            },
        )
        self.program(
            'variant Lamp\non off\n\nmain > i\nmatch tag Lamp on on 1 off fail "unused" end'
        )
        self.assertEqual(self.cli("run", self.src), 1)
        view = self.cli("context", self.src, "--function", "main", "--node", "5:1")
        self.assertEqual(view["variants"], {"Lamp": ["off", "on"]})
        for key in ("compact", "expanded"):
            edit = json.dumps([{"node": "5:1", "replace": view["selection"][key]}])
            self.cli("edit", self.src, "--base", view["revision"], "--edits", edit)
        edit = json.dumps([{"node": "5:1", "replace": "match tag Lamp off on 9 end"}])
        self.cli(
            "edit",
            self.src,
            "--base",
            view["revision"],
            "--edits",
            edit,
            "--write",
            error="E_MATCH",
        )
        self.assertEqual(self.cli("run", self.src), 1)

    def test_offline_catalog_examples(self):
        from tide_lang.catalog import CATALOG

        expected = {
            "+": ("i", 9),
            "-": ("i", 5),
            "*": ("i", 14),
            "div": ("i", -3),
            "mod": ("i", -1),
            "<": ("b", True),
            ">": ("b", True),
            "eq": ("b", True),
            "not": ("b", True),
            "and": ("b", False),
            "or": ("b", True),
            "if": ("i", 5),
            "let": ("i", 6),
            "pair": ("&ib", [1, True]),
            "first": ("i", 4),
            "second": ("b", False),
            "list": ("*i", [7, 8]),
            "make": ("{Sample}", {"value": 7}),
            "tag": ("{Signal}", "green"),
            "match": ("i", 1),
            "get": ("i", 2),
            "with": ("{Sample}", {"value": 8}),
            "fold": ("i", 7),
            "scan": ("*b", [True, False]),
            "nil": ("?i", {"none": True}),
            "some": ("?i", {"some": 8}),
            "case": ("i", 9),
            "need": ("i", 8),
            "int": ("?i", {"some": -20}),
            "lines": ("*t", ["a", "b"]),
            "read": ("t", "sample"),
            "concat": ("t", "abcd"),
            "text_len": ("i", 2),
            "text_slice": ("t", "Ω"),
            "text_find": ("?i", {"some": 3}),
            "text_rfind": ("?i", {"some": 0}),
            "text_eq": ("b", False),
            "length": ("i", 0),
            "at": ("?i", {"some": 4}),
            "append": ("*i", [3, 4]),
            "catch": ("i", 7),
            "fail": ("i", "E_DATA"),
            "input_line": ("i", 3),
            "has_reason": ("b", True),
            "raise": ("i", "E_DATA"),
        }
        self.assertEqual(set(expected), CATALOG.keys())
        prelude = "record Sample\nvalue:i\n\nvariant Signal\nred green\n\nrule pump level:i > b\nstate on:b=false\nelse -> on=set < level 20\nout on\n\n"
        blocks = []
        for i, (op, (typ, want)) in enumerate(expected.items()):
            arg = (
                " input:r"
                if op == "read"
                else " sample:{Sample}"
                if op in ("get", "with")
                else ""
            )
            inputs = (
                {"input": "sample"}
                if op == "read"
                else {"sample": {"value": 2}}
                if arg
                else {}
            )
            example = (
                {"inputs": inputs, "expect_error": {"code": "E_DATA"}}
                if want == "E_DATA"
                else {"inputs": inputs, "expect": want}
            )
            blocks.extend(
                [
                    f"demo{i}{arg} > {typ}\n{CATALOG[op]['example']}",
                    f"example probe{i} demo{i}\n" + json.dumps(example),
                ]
            )
        self.assertEqual(
            self.cli("test", self.program(prelude + "\n\n".join(blocks))),
            {"passed": len(CATALOG)},
        )

    def test_hole_and_transitive_impact(self):
        self.program(
            'helper n:i > i\n+ n fail "bad"\n\nbridge v:i > i\nhelper v\n\nmain > i\nbridge 1\n\n'
            'example saved main\n{"inputs":{},"expect_error":{"code":"E_DATA"}}'
        )
        response = self.cli("context", self.src, "--function", "helper")
        self.assertEqual(response["affected_callers"], ["bridge", "main"])
        self.assertEqual(len(response["examples"][0]["contract_sha256"]), 64)
        hole = self.cli("hole", self.src, "--function", "helper", "--node", "2:5")
        self.assertEqual(hole["expected_type"], "i")
        self.assertEqual(hole["bindings"], {"n": "i"})
        original = self.src.read_bytes()
        self.cli(
            "edit",
            self.src,
            "--base",
            hole["revision"],
            "--write",
            "--edits",
            json.dumps([hole["draft_edit"]]),
            error="E_NAME",
        )
        self.assertEqual(self.src.read_bytes(), original)

    def test_physical_files_and_modular_app(self):
        fixture = self.dir / "readings.txt"
        fixture.write_bytes(b"80\r\n81\r\n98\n")
        report = ROOT / "apps/report.tide"
        self.assertEqual(
            self.cli(
                "run", report, "--inputs", '{"limit":80}', "--read", f"input={fixture}"
            ),
            {"above": 2, "peak": {"some": 98}},
        )
        self.assertEqual(self.cli("test", report), {"passed": 3})
        src = self.program(
            "leaf x:r > t\nread x\n\nproxy y:r > t\nleaf y\n\nmain input:r > t\nproxy input"
        )
        self.assertEqual(
            self.cli("check", src)["definitions"]["main"]["effects"], ["read"]
        )
        self.assertEqual(
            self.cli("run", src, "--read", f"input={fixture}"), "80\r\n81\r\n98\n"
        )

    def test_model_workflow_on_report(self):
        for name in ("readings.tide", "report.tide"):
            (self.dir / name).write_bytes((ROOT / "apps" / name).read_bytes())
        report = self.dir / "report.tide"
        before = report.read_bytes()
        view = self.cli("context", report, "--function", "main")
        comparison = next(
            node["node"] for node in view["nodes"] if node["operation"] == ">"
        )
        hole = self.cli("hole", report, "--function", "main", "--node", comparison)
        self.assertEqual(hole["expected_type"], "b")
        self.assertEqual(hole["bindings"]["value"], "i")
        edit = ["edit", report, "--base", hole["revision"], "--edits"]

        def patch(expr):
            return json.dumps([{**hole["draft_edit"], "replace": expr}])

        fail = self.cli(*edit, patch("not < value limit"), "--write", error="E_EXAMPLE")
        self.assertEqual(
            (fail["example"], fail["expected"]["above"], fail["actual"]["above"]),
            ("threshold", 2, 3),
        )
        self.assertEqual(report.read_bytes(), before)
        success = self.cli(*edit, patch("< limit value"), "--write")
        self.assertEqual(success["examples"], {"passed": 3})
        self.assertEqual(self.cli("test", report), {"passed": 3})
