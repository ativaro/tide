"""Exercise full TIDE game ticks and the real terminal entry point."""

import fcntl
import os
import pty
import select
import struct
import subprocess
import termios
import time
import unittest
from pathlib import Path

from tide_lang.core import Error
from tide_lang.program import compile_source
from tide_lang.runtime import Run
from tide_lang.workbench import project

ROOT = Path(__file__).resolve().parents[1]
GAME = ROOT / "apps" / "space_invaders.tide"


class InvadersTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.defs, _ = compile_source(*project(GAME))

    def call(self, name, **inputs):
        return Run(self.defs).eval(self.defs[name].body, inputs)

    def tick(self, game, **keys):
        buttons = dict.fromkeys(("left", "right", "fire", "pause", "start"), False)
        return self.call("tick", world=game, keys=buttons | keys)

    def test_playthroughs(self):
        for playing in (True, False):
            game = self.tick(self.call("main"), start=True)
            for _ in range(2500):
                if game["mode"] in ("won", "lost"):
                    break
                if not playing:
                    game = self.tick(game)
                    continue
                # Aim ahead of the closest column using only the visible game state.
                period = self.call("formation_period", count=len(game["aliens"]))
                columns = (
                    max(
                        2,
                        min(
                            58,
                            a["x"]
                            + game["direction"]
                            * ((game["age"] % period + max(0, 18 - a["y"])) // period),
                        ),
                    )
                    for a in game["aliens"]
                )
                aim = min(columns, key=lambda x: abs(x - game["ship"]))
                game = self.tick(
                    game,
                    fire=True,
                    left=game["ship"] > aim + 1,
                    right=game["ship"] < aim - 1,
                )
            self.assertEqual(game["mode"], "won" if playing else "lost")
            if playing:
                self.assertEqual((len(game["aliens"]), game["score"]), (0, 420))
            self.assertEqual(self.tick(game, fire=True), game)
            self.assertEqual(self.tick(game, start=True), self.call("new_game"))

    def test_damage_and_pause(self):
        game = self.call("new_game")
        paused = self.tick(game, pause=True)
        self.assertEqual(self.tick(paused, fire=True, right=True), paused)
        self.assertEqual(self.tick(paused, pause=True), game)
        # Two projectiles reach the middle bunker in the same tick.
        game.update(age=1, shot={"some": [30, 17]}, bomb={"some": [30, 15]})
        after = self.tick(game)
        self.assertEqual(after["bunkers"][1]["hp"], 1)
        self.assertEqual(after["shot"], {"none": True})
        self.assertEqual(after["bomb"], {"none": True})
        game.update(bomb={"some": [30, 18]}, lives=1)
        self.assertEqual(self.tick(game)["mode"], "lost")
        game["grace"] = 8
        self.assertEqual(self.tick(game)["lives"], 1)

    def test_respawn(self):
        game = self.call("new_game") | {"age": 1, "bomb": {"some": [30, 18]}}
        hit = self.tick(game)
        self.assertEqual((hit["mode"], hit["lives"], hit["grace"]), ("respawn", 2, 16))
        title = "T R E F F E R"
        self.assertIn(title, [g["text"] for g in self.call("draw", world=hit)])
        state = hit
        for grace in range(15, 7, -1):
            state = self.tick(state, right=True, fire=True, start=True, pause=True)
            mode = "playing" if grace == 8 else "respawn"
            self.assertEqual(state, hit | {"mode": mode, "grace": grace})
        self.assertNotIn(title, [g["text"] for g in self.call("draw", world=state)])
        # Put a bomb on the ship each tick, accounting for its alternating movement.
        for grace in range(7, -1, -1):
            y = 19 if state["age"] % 2 == 0 else 18
            state = self.tick(state | {"bomb": {"some": [30, y]}})
            self.assertEqual(
                (state["mode"], state["lives"], state["grace"]), ("playing", 2, grace)
            )
        self.assertEqual(
            self.tick(state | {"bomb": {"some": [30, 19]}})["mode"], "respawn"
        )

    def test_simultaneous_last_alien_and_hit(self):
        world = self.call("new_game") | {
            "aliens": [{"x": 20, "y": 5, "row": 0}],
            "shot": {"some": [20, 6]},
            "bomb": {"some": [30, 19]},
        }
        for lives, mode in [(1, "lost"), (2, "won")]:
            after = self.tick(world | {"lives": lives})
            self.assertEqual(
                (after["mode"], after["lives"], after["aliens"]), (mode, lives - 1, [])
            )

    def test_one_more_phase(self):
        source, modules = project(GAME)
        lib = "invaders_game.tide"
        changed = modules[lib].replace("variant Phase\n", "variant Phase\nextra_phase ")
        with self.assertRaises(Error) as failure:
            compile_source(source, modules | {lib: changed})
        self.assertEqual(failure.exception.code, "E_MATCH")
        issues = failure.exception.data["diagnostics"]
        self.assertCountEqual(
            [
                (d.get("file"), d["definition"], d["variant"], d["missing"])
                for d in issues
            ],
            [
                (None, "draw", "Phase", ["extra_phase"]),
                (lib, "tick", "Phase", ["extra_phase"]),
            ],
        )

    def test_terminal_start_pause_quit(self):
        master, slave = pty.openpty()
        self.addCleanup(os.close, master)
        self.addCleanup(os.close, slave)
        fcntl.ioctl(slave, termios.TIOCSWINSZ, struct.pack("HHHH", 24, 80, 0, 0))
        with subprocess.Popen(
            [ROOT / "tide", "play", GAME],
            stdin=slave,
            stdout=slave,
            stderr=slave,
            env={**os.environ, "TERM": "xterm-256color"},
        ) as proc:

            def wait_for(label):
                output = bytearray()
                deadline = time.monotonic() + 5
                while label not in output:
                    left = deadline - time.monotonic()
                    self.assertGreater(left, 0, repr(output[-400:]))
                    if select.select([master], [], [], left)[0]:
                        output.extend(os.read(master, 8192))

            try:
                wait_for(b"SPIEL STARTEN")
                os.write(master, b"\r")
                # Only the running formation reaches its second animation frame.
                wait_for(b"{o}")
                os.write(master, b"p")
                wait_for(b"WEITER")
                os.write(master, b"q")
                self.assertEqual(proc.wait(timeout=3), 0)
            finally:
                if proc.poll() is None:
                    proc.kill()
