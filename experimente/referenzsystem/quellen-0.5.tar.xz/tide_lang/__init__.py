"""TIDE language implementation."""
