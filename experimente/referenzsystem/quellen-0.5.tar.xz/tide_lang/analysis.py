"""Inspect the checked tree used by the interpreter."""

from .catalog import CATALOG
from .core import Error, Expr, require


def roots(d):
    yield from d.starts.values()
    for guard, actions in d.rows:
        if guard is not None:
            yield guard
        yield from (a for a in actions.values() if isinstance(a, Expr))
    yield d.body


def children(expr):
    return (x for x in expr.args if isinstance(x, Expr))


def analyze(defs):
    done = set()
    incomplete = []

    def visit(d):
        if d.name in done:
            return
        for dep in sorted(d.calls):
            visit(defs[dep])
        effects = set()
        read_paths = []

        def walk(expr):
            op, xs = expr.op, expr.args
            if op == "match":
                variant = xs[0].typ[1:-1]
                missing = defs.types[variant] - xs[1].keys()
                if missing:
                    issue = Error(
                        "E_MATCH",
                        "Missing match branches",
                        expr.at,
                        definition=d.name,
                        variant=variant,
                        missing=sorted(missing),
                    )
                    incomplete.append(issue.data)
            if op == "catch":
                return (walk(xs[1]) - {xs[0]}) | walk(xs[3])
            errors = set(CATALOG.get(op, {}).get("may_fail", []))
            if op == "raise":
                errors.add(xs[0].typ[1:])
            if op == "read":
                effects.add("read")
                read_paths.append((d.name, "read"))
            if op in ("call", "scan"):
                target = defs[xs[0]]
                errors.update(target.may_fail)
                effects.update(target.effects)
                if target.read_path:
                    read_paths.append((d.name, *target.read_path))
            for child in children(expr):
                errors.update(walk(child))
            return errors

        errors = set()
        for expr in roots(d):
            errors.update(walk(expr))
        d.read_path = min(read_paths, key=lambda path: (len(path), path), default=())
        d.effects = sorted(effects)
        d.may_fail = sorted(errors)
        require(
            not d.rule or not effects,
            "E_CAPABILITY",
            "Rule has external effects",
            d.at,
            rule=d.name,
            call_chain=d.read_path,
            effects=d.effects,
        )
        done.add(d.name)

    for d in defs.values():
        visit(d)
    require(
        not incomplete,
        "E_MATCH",
        "Non-exhaustive variant matches",
        diagnostics=incomplete,
    )


def info(d):
    return {
        "kind": "rule" if d.rule else "function",
        "params": d.params,
        "returns": d.ret,
        "calls": sorted(d.calls),
        "effects": d.effects,
        "read_grants": [k for k, t in d.params.items() if t == "r"],
        "read_path": d.read_path,
        "may_fail": d.may_fail,
    }
