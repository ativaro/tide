"""Typed prefix expressions for the first TIDE interpreter."""

import json
import re
from dataclasses import dataclass

from .catalog import CATALOG, CATCHABLE
from .values import MAX_ITEMS, components, data_type, integer, named_types, valid_text

OPS = set(CATALOG)
RESERVED = OPS | {
    "true",
    "false",
    "use",
    "record",
    "variant",
    "end",
    "rule",
    "example",
    "state",
    "when",
    "else",
    "out",
    "_",
    "set",
    "keep",
    "reset",
    "E_OVERFLOW",
    "E_DATA",
}
LEX = re.compile(r'"(?:\\.|[^"\\])*"|[(),=]|[^\s()",=]+|"')


@dataclass(frozen=True)
class Token:
    word: str
    line: int
    col: int
    file: str | None = None


def lex(line, number, file=None):
    return [Token(m[0], number, m.start() + 1, file) for m in LEX.finditer(line)]


class Error(Exception):
    def __init__(self, code, message, at=None, **details):
        super().__init__(message)
        self.code = code
        self.data = {"code": code, "message": message, **details}
        if at:
            self.data.update(line=at.line, column=at.col)
            if at.file:
                self.data["file"] = at.file


def require(ok, code, message, at=None, **details):
    if not ok:
        raise Error(code, message, at, **details)


def identifier(name):
    return re.fullmatch(r"[a-zA-Z][a-zA-Z0-9_]*", name) and name not in RESERVED


def binding(name, names, at):
    require(
        identifier(name) and name not in names,
        "E_NAME",
        "Invalid or duplicate name: " + name,
        at,
    )


def check_type(actual, expected, at):
    require(
        actual in (expected, "!"),
        "E_TYPE",
        "Unexpected type",
        at,
        expected=expected,
        actual=actual,
    )


@dataclass
class Expr:
    op: str
    typ: str
    at: Token
    args: tuple
    start: Token | None = None
    end: Token | None = None
    expected: str | None = None


class Parser:
    def __init__(self, tokens, defs, owner, fallback):
        self.tokens, self.defs, self.owner = tokens, defs, owner
        self.pos = 0
        self.end = (
            Token(
                "",
                tokens[-1].line,
                tokens[-1].col + len(tokens[-1].word),
                tokens[-1].file,
            )
            if tokens
            else fallback
        )

    def take(self):
        require(self.pos < len(self.tokens), "E_SYNTAX", "Missing operand", self.end)
        token = self.tokens[self.pos]
        self.pos += 1
        return token

    def expr(self, scope, depth=0):
        tok = self.take()
        require(depth < 48, "E_LIMIT", "Expression nesting limit", tok)
        start = tok
        grouped = tok.word == "("
        if grouped:
            tok = self.take()
        op = tok.word

        def child():
            return self.expr(scope, depth + 1)

        position = 0

        def arg(t):
            nonlocal position
            position += 1
            node = child()
            require(
                node.typ in (t, "!"),
                "E_TYPE",
                "Unexpected operand type",
                node.at,
                operation=op,
                argument=position,
                expected=t,
                actual=node.typ,
            )
            node.expected = t
            return node

        def local(env):
            name = self.take()
            binding(name.word, env.keys() | self.defs.keys(), name)
            return name.word

        def node(typ, *xs):
            return Expr(op, typ, tok, xs)

        def diag():
            name = self.take()
            typ = scope.get(name.word, "")
            require(
                typ.startswith("#"), "E_TYPE", "Handler diagnostic name required", name
            )
            return Expr("var", typ, name, (name.word,), name, name)

        if op.startswith('"'):
            try:
                value = json.loads(op)
            except ValueError:
                value = None
            require(valid_text(value), "E_SYNTAX", "Invalid UTF-8 text literal", tok)
            result = Expr("lit", "t", tok, (value,))
        elif op in scope:
            require(
                not scope[op].startswith("#"),
                "E_TYPE",
                "Diagnostic requires a diagnostic operation",
                tok,
            )
            result = Expr("var", scope[op], tok, (op,))
        elif op in ("true", "false"):
            result = Expr("lit", "b", tok, (op == "true",))
        elif re.fullmatch(r"-?[0-9]+", op):
            value = integer(op)
            require(value is not None, "E_RANGE", "Integer outside i64", tok)
            result = Expr("lit", "i", tok, (value,))
        elif op in ("+", "-", "*", "div", "mod", "<", ">", "eq"):
            result = node("b" if op in ("<", ">", "eq") else "i", arg("i"), arg("i"))
        elif op in ("and", "or"):
            result = node("b", arg("b"), arg("b"))
        elif op == "not":
            result = node("b", arg("b"))
        elif op in ("concat", "text_eq"):
            result = node("t" if op == "concat" else "b", arg("t"), arg("t"))
        elif op == "text_len":
            result = node("i", arg("t"))
        elif op == "text_slice":
            result = node("t", arg("t"), arg("i"), arg("i"))
        elif op in ("text_find", "text_rfind"):
            result = node("?i", arg("t"), arg("t"), arg("i"))
        elif op in ("int", "lines", "read"):
            result = node(
                {"int": "?i", "lines": "*t", "read": "t"}[op],
                arg("r" if op == "read" else "t"),
            )
        elif op == "nil":
            typ = self.take()
            require(data_type(typ.word), "E_TYPE", "Expected data type", typ)
            result = node("?" + typ.word)
        elif op == "tag":
            name, label = self.take(), self.take()
            tags = self.defs.types.get(name.word)
            require(
                isinstance(tags, frozenset), "E_TYPE", "Expected a variant type", name
            )
            if label.word not in tags:
                raise Error(
                    "E_TAG",
                    "Unknown variant tag",
                    label,
                    variant=name.word,
                    tag=label.word,
                    allowed=sorted(tags),
                )
            result = node("{" + name.word + "}", name.word, label.word)
        elif op == "match":
            subject = child()
            name = subject.typ[1:-1]
            tags = self.defs.types.get(name) if subject.typ.startswith("{") else None
            require(
                isinstance(tags, frozenset),
                "E_TYPE",
                "Expected a variant value",
                subject.at,
                actual=subject.typ,
            )
            arms = {}
            typ = "!"
            while True:
                require(
                    self.pos < len(self.tokens),
                    "E_SYNTAX",
                    "Missing end of match",
                    self.end,
                )
                label = self.take()
                if label.word == "end":
                    break
                require(label.word != ")", "E_SYNTAX", "Expected end of match", label)
                require(
                    label.word in tags,
                    "E_TAG",
                    "Unknown match tag",
                    label,
                    variant=name,
                    tag=label.word,
                )
                require(
                    label.word not in arms,
                    "E_TAG",
                    "Duplicate match tag",
                    label,
                    variant=name,
                    tag=label.word,
                )
                branch = child()
                if typ == "!":
                    typ = branch.typ
                check_type(branch.typ, typ, branch.at)
                arms[label.word] = branch
            for branch in arms.values():
                branch.expected = typ
            # Keep branch nodes visible to ordinary tree traversal, with direct tag dispatch.
            indices = {label: i for i, label in enumerate(arms)}
            result = node(typ, subject, indices, *arms.values())
        elif op == "make":
            tag = self.take()
            fields = self.defs.types.get(tag.word)
            require(isinstance(fields, dict), "E_TYPE", "Unknown record", tag)
            items = [tag.word]
            for key, t in fields.items():
                field = self.take()
                require(
                    field.word == key,
                    "E_FIELD",
                    "Expected named field",
                    field,
                    expected=key,
                    actual=field.word,
                )
                items.extend((key, arg(t)))
            result = node("{" + tag.word + "}", *items)
        elif op in ("get", "with"):
            field = self.take()
            record = child()
            fields = (
                self.defs.types.get(record.typ[1:-1])
                if record.typ.startswith("{")
                else None
            )
            require(
                isinstance(fields, dict) and field.word in fields,
                "E_FIELD",
                "Unknown record field",
                field,
                field=field.word,
                actual=record.typ,
            )
            if op == "get":
                result = node(fields[field.word], field.word, record)
            else:
                result = node(record.typ, field.word, record, arg(fields[field.word]))
        elif op == "some":
            item = child()
            result = node("!" if item.typ == "!" else "?" + item.typ, item)
        elif op in ("case", "need"):
            optional = child()
            require(
                optional.typ == "!" or optional.typ.startswith("?"),
                "E_TYPE",
                "Option expected",
                optional.at,
            )
            if op == "need":
                result = node(optional.typ[1:] or "!", optional, arg("t"), arg("i"))
            else:
                empty = child()
                name = local(scope)
                full = self.expr({**scope, name: optional.typ[1:] or "!"}, depth + 1)
                typ = full.typ if empty.typ == "!" else empty.typ
                check_type(full.typ, typ, full.at)
                empty.expected = full.expected = typ
                result = node(typ, optional, empty, name, full)
        elif op in ("length", "at", "append"):
            seq = child()
            require(
                seq.typ == "!" or seq.typ.startswith("*"),
                "E_TYPE",
                "List expected",
                seq.at,
            )
            if op == "length":
                result = node("i", seq)
            elif op == "at":
                result = node(
                    "!" if seq.typ == "!" else "?" + seq.typ[1:], seq, arg("i")
                )
            else:
                result = node(
                    seq.typ, seq, child() if seq.typ == "!" else arg(seq.typ[1:])
                )
        elif op == "if":
            guard, yes, no = arg("b"), child(), child()
            typ = no.typ if yes.typ == "!" else yes.typ
            check_type(no.typ, typ, no.at)
            yes.expected = no.expected = typ
            result = node(typ, guard, yes, no)
        elif op == "pair":
            a, b = child(), child()
            result = node("!" if "!" in (a.typ, b.typ) else "&" + a.typ + b.typ, a, b)
        elif op in ("first", "second"):
            p = child()
            require(
                p.typ == "!" or p.typ.startswith("&"), "E_TYPE", "Pair expected", p.at
            )
            result = node(
                "!" if p.typ == "!" else components(p.typ)[0 if op == "first" else 1], p
            )
        elif op == "list":
            typ, count = self.take(), self.take()
            require(data_type(typ.word), "E_TYPE", "Unsupported element type", typ)
            require(
                re.fullmatch(r"[0-9]{1,6}", count.word),
                "E_SYNTAX",
                "Invalid list count",
                count,
            )
            n = int(count.word)
            require(n <= MAX_ITEMS, "E_LIMIT", "List length limit", count)
            result = node("*" + typ.word, *(arg(typ.word) for _ in range(n)))
        elif op == "let":
            name = local(scope)
            value = child()
            body = self.expr({**scope, name: value.typ}, depth + 1)
            result = node(body.typ, name, value, body)
        elif op == "fold":
            seq, start = child(), child()
            require(
                seq.typ == "!" or seq.typ.startswith("*"),
                "E_TYPE",
                "List expected",
                seq.at,
            )
            env = dict(scope)
            names = []
            for typ in (start.typ, "i", seq.typ[1:] or "!"):
                name = local(env)
                env[name] = typ
                names.append(name)
            body = self.expr(env, depth + 1)
            if start.typ != "!":
                check_type(body.typ, start.typ, body.at)
                body.expected = start.typ
            result = node(start.typ, seq, start, tuple(names), body)
        elif op == "catch":
            code = self.take()
            require(code.word in CATCHABLE, "E_TYPE", "Unsupported catch target", code)
            body = child()
            binder = self.take()
            env = scope
            if binder.word != "_":
                binding(binder.word, scope.keys() | self.defs.keys(), binder)
                env = {**scope, binder.word: "#" + code.word}
            alt = self.expr(env, depth + 1)
            typ = alt.typ if body.typ == "!" else body.typ
            check_type(alt.typ, typ, alt.at)
            body.expected = alt.expected = typ
            result = node(typ, code.word, body, binder.word, alt)
        elif op == "fail":
            result = node("!", arg("t"))
        elif op == "raise":
            result = node("!", diag())
        elif op == "input_line":
            result = node("?i", diag())
        elif op == "has_reason":
            result = node("b", diag(), arg("t"))
        elif op == "scan" or op in self.defs:
            name = self.take() if op == "scan" else tok
            target = self.defs.get(name.word)
            require(
                target and target.rule == (op == "scan"),
                "E_NAME",
                "Invalid call target: " + name.word,
                name,
            )
            self.owner.calls.add(name.word)
            if op == "scan":
                ret = "*" + target.ret
                require(
                    data_type(ret), "E_TYPE", "Nested scan results unsupported", name
                )
                result = node(
                    ret, name.word, arg("*" + next(iter(target.params.values())))
                )
            else:
                result = Expr(
                    "call",
                    target.ret,
                    tok,
                    (op, *(arg(t) for t in target.params.values())),
                )
        else:
            raise Error(
                "E_SYNTAX" if op in ("(", ")", ",") else "E_NAME",
                "Unexpected token: " + op,
                tok,
            )
        if grouped:
            require(
                op in OPS or op in self.defs,
                "E_SYNTAX",
                "Only calls may be grouped",
                tok,
            )
            end = self.take()
            require(end.word == ")", "E_SYNTAX", "Expected closing parenthesis", end)
        require(
            result.typ in ("!", "r")
            or (
                data_type(result.typ)
                and all(n in self.defs.types for n in named_types(result.typ))
            ),
            "E_TYPE",
            "Invalid or excessively nested data type",
            tok,
            actual=result.typ,
        )
        return Expr(
            result.op, result.typ, tok, result.args, start, self.tokens[self.pos - 1]
        )

    def full(self, scope):
        result = self.expr(scope)
        if self.pos < len(self.tokens):
            raise Error("E_SYNTAX", "Extra operand", self.tokens[self.pos])
        return result
