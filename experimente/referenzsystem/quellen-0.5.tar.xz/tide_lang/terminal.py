"""Keyboard, fixed clock and character display for TIDE terminal programs."""

import curses
import sys
import time

from .core import Error, require
from .runtime import Run

KEYS = dict.fromkeys(("left", "right", "fire", "start", "pause"), "b")
GLYPH = {"x": "i", "y": "i", "text": "t", "ink": "t"}
BINDINGS = {
    curses.KEY_LEFT: "left",
    ord("a"): "left",
    ord("A"): "left",
    curses.KEY_RIGHT: "right",
    ord("d"): "right",
    ord("D"): "right",
    ord(" "): "fire",
    10: "start",
    13: "start",
    curses.KEY_ENTER: "start",
    ord("p"): "pause",
    ord("P"): "pause",
}
QUIT = {27, ord("q"), ord("Q")}
FRAME_SECONDS = 1 / 12


def check_interface(defs):
    main = defs.get("main")
    require(main, "E_ENTRY", "A playable program needs main")
    signatures = {
        "main": ({}, main.ret),
        "size": ({}, "&ii"),
        "tick": ({"world": main.ret, "keys": "{Keys}"}, main.ret),
        "draw": ({"world": main.ret}, "*{Glyph}"),
    }
    for name, (params, ret) in signatures.items():
        d = defs.get(name)
        require(
            d and not d.rule and not d.effects and d.params == params and d.ret == ret,
            "E_PLAY",
            "Invalid terminal function",
            function=name,
            params=params,
            returns=ret,
        )
    require(
        defs.records.get("Keys") == KEYS and defs.records.get("Glyph") == GLYPH,
        "E_PLAY",
        "Expected terminal input and drawing records",
        Keys=KEYS,
        Glyph=GLYPH,
    )


def palette():
    colors = {
        "dim": curses.COLOR_WHITE,
        "cyan": curses.COLOR_CYAN,
        "green": curses.COLOR_GREEN,
        "pink": curses.COLOR_MAGENTA,
        "gold": curses.COLOR_YELLOW,
        "white": curses.COLOR_WHITE,
    }
    styles = {name: curses.A_DIM if name == "dim" else curses.A_BOLD for name in colors}
    if curses.has_colors():
        for i, (name, color) in enumerate(colors.items(), 1):
            if i < curses.COLOR_PAIRS and color < curses.COLORS:
                curses.init_pair(i, color, curses.COLOR_BLACK)
                styles[name] |= curses.color_pair(i)
    return styles


def paint(screen, x, y, text, style, clip):
    height, width = screen.getmaxyx()
    count = min(clip, width - x)
    if not (0 <= y < height and 0 <= x < width and count > 0):
        return
    # Leave the terminal's bottom-right cell alone: writing it may request a scroll.
    if y == height - 1:
        count = min(count, width - x - 1)
    if count > 0:
        screen.addstr(
            y, x, "".join(c if " " <= c <= "~" else "?" for c in text[:count]), style
        )


def play(defs):
    check_interface(defs)
    require(
        sys.stdin.isatty() and sys.stdout.isatty(),
        "E_TERMINAL",
        "play needs an interactive terminal",
    )

    def call(name, **env):
        return Run(defs).eval(defs[name].body, env)

    width, height = call("size")
    require(width > 0 and height > 0, "E_PLAY", "size must return positive dimensions")

    def loop(screen):
        screen.keypad(True)
        screen.nodelay(True)
        try:
            curses.curs_set(0)
        except curses.error:
            pass
        curses.set_escdelay(25)
        styles = palette()
        world = call("main")
        while True:
            started = time.monotonic()
            keys = dict.fromkeys(KEYS, False)
            while (key := screen.getch()) != -1:
                if key in QUIT:
                    return
                if key in BINDINGS:
                    keys[BINDINGS[key]] = True
            rows, cols = screen.getmaxyx()
            screen.erase()
            if cols >= width and rows >= height:
                world = call("tick", world=world, keys=keys)
                left, top = (cols - width) // 2, (rows - height) // 2
                for mark in call("draw", world=world):
                    x, y = mark["x"], mark["y"]
                    if 0 <= x < width and 0 <= y < height:
                        paint(
                            screen,
                            left + x,
                            top + y,
                            mark["text"],
                            styles.get(mark["ink"], 0),
                            width - x,
                        )
            else:
                paint(
                    screen,
                    0,
                    0,
                    f"Terminal: {width} x {height} benoetigt. Q beendet.",
                    0,
                    cols,
                )
            screen.refresh()
            time.sleep(max(0, FRAME_SECONDS - (time.monotonic() - started)))

    try:
        curses.wrapper(loop)
    except KeyboardInterrupt:
        return
    except curses.error as exc:
        raise Error("E_TERMINAL", f"Terminal unavailable: {exc}") from None
