"""Evaluate checked nodes with one work budget per invocation or example."""

import io

from .core import Error, require
from .values import (
    MAX,
    MAX_ITEMS,
    MAX_MEMORY,
    MAX_SOURCE,
    MAX_STEPS,
    MIN,
    Grant,
    integer,
    option,
)


class Run:
    def __init__(self, definitions):
        self.defs = definitions
        self.remaining = MAX_STEPS
        self.memory = MAX_MEMORY
        self.read_bytes = 0

    def tick(self, at, amount=1):
        self.remaining -= amount
        require(self.remaining >= 0, "E_LIMIT", "Work budget exhausted", at)

    def charge(self, value, at):
        # Charge logical size, including repeated references in a composite.
        if isinstance(value, list):
            self.memory -= 8 * (1 + len(value))
            for v in value:
                self.charge(v, at)
        elif isinstance(value, dict):
            self.memory -= 16
            for v in value.values():
                self.charge(v, at)
        elif isinstance(value, str):
            self.memory -= 8 + 4 * len(value)
        else:
            self.memory -= 8
        require(self.memory >= 0, "E_LIMIT", "Guest allocation budget exhausted", at)
        return value

    def read(self, grant, at):
        require(
            isinstance(grant, Grant),
            "E_CAPABILITY",
            "A read capability is required",
            at,
        )
        if grant.snapshot is None:
            try:
                raw = grant.handle.read(MAX_SOURCE - self.read_bytes + 1)
            except OSError as e:
                raise Error("E_IO", "Granted read failed", at) from e
            self.read_bytes += len(raw)
            require(
                self.read_bytes <= MAX_SOURCE,
                "E_LIMIT",
                "Read byte budget exhausted",
                at,
            )
            grant.snapshot = raw
        self.tick(at, 1 + len(grant.snapshot) // 32)
        try:
            text = grant.snapshot.decode("utf-8")
        except UnicodeDecodeError:
            raise Error("E_UTF8", "Invalid UTF-8 input", at) from None
        return self.charge(text, at)

    def scan(self, rule, events, trace=None):
        initial = {name: self.eval(expr, {}) for name, expr in rule.starts.items()}
        state, output = initial, []
        param = next(iter(rule.params))
        for index, event in enumerate(events, 1):
            try:
                self.tick(rule.at)
                prior = {param: event, **state}
                for branch, (guard, actions) in enumerate(rule.rows, 1):
                    if guard is None or self.eval(guard, prior):
                        break
                updated = {}
                for name, initial_value in initial.items():
                    self.tick(rule.at)
                    action = actions[name]
                    if action == "keep":
                        updated[name] = state[name]
                    elif action == "reset":
                        updated[name] = initial_value
                    else:
                        updated[name] = self.eval(action, prior)
                value = self.eval(rule.body, {param: event, **updated})
                if trace:
                    trace(index, event, branch, actions, state, updated, value)
                self.charge(value, rule.at)
                state = updated
                output.append(value)
            except Error as e:
                e.data.setdefault("event", index)
                raise
        return output

    def eval(self, expr, env):
        self.tick(expr.at)
        op, xs = expr.op, expr.args

        def val(node):
            return self.eval(node, env)

        if op == "lit":
            return xs[0]
        if op == "var":
            return env[xs[0]]
        if op == "tag":
            return xs[1]
        if op == "match":
            label = val(xs[0])
            return val(xs[2 + xs[1][label]])
        if op == "if":
            return val(xs[1] if val(xs[0]) else xs[2])
        if op == "let":
            key, value, body = xs
            return self.eval(body, {**env, key: val(value)})
        if op == "fold":
            seq, start, names, body = xs
            items, acc = val(seq), val(start)
            local = dict(env)
            key, pos, elem = names
            for i, v in enumerate(items, 1):
                local[key], local[pos], local[elem] = acc, i, v
                acc = self.eval(body, local)
            return acc
        if op == "scan":
            return self.scan(self.defs[xs[0]], val(xs[1]))
        if op == "call":
            d = self.defs[xs[0]]
            return self.eval(
                d.body, dict(zip(d.params, (val(x) for x in xs[1:]), strict=True))
            )
        if op == "catch":
            try:
                return val(xs[1])
            except Error as e:
                if e.code != xs[0]:
                    raise
                handler = env if xs[2] == "_" else {**env, xs[2]: e}
            return self.eval(xs[3], handler)
        if op == "fail":
            raise Error("E_DATA", "Data rejected", expr.at, reason=val(xs[0]))
        if op == "raise":
            raise val(xs[0])
        if op == "input_line":
            return option(val(xs[0]).data.get("input_line"))
        if op == "has_reason":
            return val(xs[0]).data.get("reason") == val(xs[1])
        if op == "nil":
            return option(None)
        if op == "some":
            return self.charge(option(val(xs[0])), expr.at)
        if op == "case":
            value = val(xs[0])
            return (
                val(xs[1])
                if "none" in value
                else self.eval(xs[3], {**env, xs[2]: value["some"]})
            )
        if op == "need":
            value = val(xs[0])
            if "some" in value:
                return value["some"]
            raise Error(
                "E_DATA",
                "A value is required",
                expr.at,
                reason=val(xs[1]),
                input_line=val(xs[2]),
            )
        if op == "read":
            return self.read(val(xs[0]), expr.at)
        if op in ("lines", "int"):
            text = val(xs[0])
            self.tick(expr.at, 1 + len(text) // 32)
            if op == "int":
                return option(integer(text))
            lines = text.replace("\r\n", "\n").split("\n")
            if not lines[-1]:
                lines.pop()
            require(len(lines) <= MAX_ITEMS, "E_LIMIT", "Line count limit", expr.at)
            return self.charge(lines, expr.at)
        if op in ("pair", "list"):
            return self.charge([val(x) for x in xs], expr.at)
        if op in ("first", "second"):
            return val(xs[0])[0 if op == "first" else 1]
        if op == "make":
            return self.charge(
                {xs[j]: val(xs[j + 1]) for j in range(1, len(xs), 2)}, expr.at
            )
        if op == "get":
            return val(xs[1])[xs[0]]
        if op == "with":
            return self.charge({**val(xs[1]), xs[0]: val(xs[2])}, expr.at)
        if op in ("length", "text_len"):
            return len(val(xs[0]))
        if op == "text_slice":
            body, start, stop = (val(x) for x in xs)
            return self.charge(body[max(0, start) : max(0, stop)], expr.at)
        if op in ("text_find", "text_rfind"):
            body, needle, bound = (val(x) for x in xs)
            bound = min(len(body), max(0, bound))
            self.tick(expr.at, 1 + (len(body) + len(needle)) // 32)
            pos = (
                body.find(needle, bound)
                if op == "text_find"
                else body.rfind(needle, 0, bound)
            )
            return option(pos if pos >= 0 else None)
        if op == "not":
            return not val(xs[0])
        if op == "and":
            return val(xs[0]) and val(xs[1])
        if op == "or":
            return val(xs[0]) or val(xs[1])
        a, b = val(xs[0]), val(xs[1])
        if op == "append":
            require(len(a) < MAX_ITEMS, "E_LIMIT", "List length limit", expr.at)
            return self.charge([*a, b], expr.at)
        if op == "at":
            return option(a[b]) if 0 <= b < len(a) else option(None)
        if op == "concat":
            require(
                4 * (len(a) + len(b)) <= self.memory,
                "E_LIMIT",
                "Text budget exhausted",
                expr.at,
            )
            return self.charge(a + b, expr.at)
        if op == "text_eq":
            self.tick(expr.at, 1 + min(len(a), len(b)) // 32)
            return a == b
        if op == "eq":
            return a == b
        if op == "<":
            return a < b
        if op == ">":
            return a > b
        if op in ("+", "-", "*", "div", "mod"):
            if op == "+":
                value = a + b
            elif op == "-":
                value = a - b
            elif op == "*":
                value = a * b
            else:
                require(
                    b != 0,
                    "E_DATA",
                    "Division by zero",
                    expr.at,
                    reason="division_by_zero",
                )
                q = (abs(a) // abs(b)) * (-1 if (a < 0) != (b < 0) else 1)
                value = q if op == "div" else a - q * b
            require(MIN <= value <= MAX, "E_OVERFLOW", "i64 overflow", expr.at)
            return value
        raise AssertionError(op)


def test_examples(defs, examples):
    for name, target, data, at in examples:
        d = defs[target]
        run = Run(defs)
        expected_error = data.get("expect_error")
        try:
            value = (
                run.scan(d, data["events"])
                if d.rule
                else run.eval(
                    d.body,
                    {
                        k: (
                            Grant(io.BytesIO(v.encode("utf-8")))
                            if d.params[k] == "r"
                            else v
                        )
                        for k, v in data["inputs"].items()
                    },
                )
            )
        except Error as e:
            if expected_error and all(
                e.data.get(k) == v for k, v in expected_error.items()
            ):
                continue
            raise Error(
                "E_EXAMPLE",
                "Example raised an unexpected error",
                at,
                example=name,
                expected=data.get("expect", expected_error),
                actual=e.data,
            ) from None
        if expected_error:
            raise Error(
                "E_EXAMPLE",
                "Expected an error",
                at,
                example=name,
                expected=expected_error,
                actual=value,
            )
        expected = data["expect"]
        if value != expected:
            if d.rule:
                i = next(
                    i
                    for i, (a, b) in enumerate(zip(value, expected, strict=True))
                    if a != b
                )
                raise Error(
                    "E_EXAMPLE",
                    "Wrong event output",
                    at,
                    example=name,
                    event=i + 1,
                    expected=expected[i],
                    actual=value[i],
                )
            raise Error(
                "E_EXAMPLE",
                "Wrong output",
                at,
                example=name,
                expected=expected,
                actual=value,
            )
    return {"passed": len(examples)}
