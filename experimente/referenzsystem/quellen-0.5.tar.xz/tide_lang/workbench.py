"""Revision-bound inspection and checked edits for TIDE source files."""

import fcntl
import hashlib
import json
import os
import re
import stat
import tempfile
from collections import defaultdict, deque
from copy import copy
from pathlib import Path

from .analysis import info, roots
from .catalog import CATALOG, identity
from .core import Error, Expr, Parser, Token, lex, require
from .program import compile_source, json_value
from .runtime import Run, test_examples
from .values import MAX_SOURCE


def revision(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def load(path, no_follow=False):
    fd = os.open(
        path,
        os.O_RDONLY
        | getattr(os, "O_NONBLOCK", 0)
        | (os.O_NOFOLLOW if no_follow else 0),
    )
    try:
        require(stat.S_ISREG(os.fstat(fd).st_mode), "E_IO", "Regular file required")
        with os.fdopen(fd, "rb", closefd=False) as f:
            raw = f.read(MAX_SOURCE + 1)
    finally:
        os.close(fd)
    require(len(raw) <= MAX_SOURCE, "E_LIMIT", "File size limit")
    try:
        return raw.decode("utf-8")
    except UnicodeDecodeError:
        raise Error("E_UTF8", "Expected UTF-8 source") from None


def check_lock(path):
    folder = Path(path).resolve().parent
    for ancestor in (folder, *folder.parents):
        lock = ancestor / "tide.lock"
        if os.path.lexists(lock):
            found = json_value(load(lock))
            require(
                found == identity(),
                "E_VERSION",
                "Project pins a different TIDE tool or catalog",
                expected=found,
                actual=identity(),
                lock=str(lock),
            )
            return


def node_id(node):
    return (
        node.at.file + ":" if node.at.file else ""
    ) + f"{node.at.line}:{node.at.col}"


def render(expr, expanded):
    op, xs = expr.op, expr.args
    if op in ("lit", "var"):
        return expr.at.word
    if op == "list":
        parts = ["list", expr.typ[1:], str(len(xs))]
    elif op == "match":
        parts = ["match", render(xs[0], expanded)]
        for label, i in xs[1].items():
            parts.extend((label, render(xs[2 + i], expanded)))
        parts.append("end")
        xs = ()
    elif op == "nil":
        parts = ["nil", expr.typ[1:]]
    elif op == "call":
        parts = []
    else:
        parts = [op]
    for child in xs:
        if isinstance(child, Expr):
            parts.append(render(child, expanded))
        elif isinstance(child, tuple):
            parts.extend(child)
        else:
            parts.append(child)
    result = " ".join(parts)
    return "(" + result + ")" if expanded else result


def locals_at(d):
    def visit(node, env):
        yield node, env
        for i, child in enumerate(node.args):
            if not isinstance(child, Expr):
                continue
            local = env
            xs = node.args
            if node.op == "let" and i == 2:
                local = {**env, xs[0]: xs[1].typ}
            elif node.op == "case" and i == 3:
                local = {**env, xs[2]: xs[0].typ[1:]}
            elif node.op == "fold" and i == 3:
                local = {
                    **env,
                    **dict(zip(xs[2], (xs[1].typ, "i", xs[0].typ[1:]), strict=True)),
                }
            elif node.op == "catch" and i == 3 and xs[2] != "_":
                local = {**env, xs[2]: "#" + xs[0]}
            yield from visit(child, local)

    scope = {**d.params, **{key: expr.typ for key, expr in d.starts.items()}}
    initial = {id(x) for x in d.starts.values()}
    for root in roots(d):
        yield from visit(root, {} if id(root) in initial else scope)


def impact(defs, name):
    reverse = defaultdict(set)
    for d in defs.values():
        for target in d.calls:
            reverse[target].add(d.name)
    seen = {name}
    pending = deque([name])
    while pending:
        for caller in reverse[pending.popleft()]:
            if caller not in seen:
                seen.add(caller)
                pending.append(caller)
    return sorted(reverse[name]), seen


def context(defs, examples, rev, name, selected=None):
    require(name in defs, "E_NAME", "Unknown definition: " + name)
    d = defs[name]
    direct, affected = impact(defs, name)
    view = {
        "revision": rev,
        "version": identity(),
        "definition": name,
        **info(d),
        "records": defs.records,
        "variants": defs.variants,
        "direct_callers": direct,
        "affected_callers": sorted(affected - {name}),
        "examples": [
            {
                "name": n,
                "target": t,
                "contract_sha256": revision(
                    json.dumps([n, t, data], sort_keys=True, separators=(",", ":"))
                ),
                **data,
            }
            for n, t, data, _ in examples
            if t in affected
        ],
    }
    nodes = []
    for node, scope in locals_at(d):
        key = node_id(node)
        entry = {"node": key, "operation": node.at.word, "type": node.typ}
        if selected == key:
            view["selection"] = {
                **entry,
                "expected_type": node.expected or node.typ,
                "bindings": scope,
                "read_grants": [n for n, t in scope.items() if t == "r"],
                "compact": render(node, False),
                "expanded": render(node, True),
            }
            return view
        if not selected:
            nodes.append(entry)
    require(selected is None, "E_NODE", "Unknown node for this definition")
    view["nodes"] = nodes
    return view


def trace(defs, examples, name, step, fields):
    matches = [(defs[target], data) for n, target, data, _ in examples if n == name]
    require(matches, "E_EXAMPLE", "Unknown example: " + name)
    rule, data = matches[0]
    require(rule.rule, "E_TYPE", "Trace needs a rule example")
    require(1 <= step <= len(data["events"]), "E_INPUT", "Event index outside example")
    selected = list(rule.starts) if fields is None else fields.split(",")
    require(all(k in rule.starts for k in selected), "E_NAME", "Unknown state field")
    record = {}

    def capture(index, event, branch, actions, old, new, out):
        if index == step:
            record.update(
                example=name,
                rule=rule.name,
                step=index,
                event=event,
                branch=branch,
                fields={
                    k: {
                        "before": old[k],
                        "action": "set" if isinstance(actions[k], Expr) else actions[k],
                        "after": new[k],
                    }
                    for k in selected
                },
                output=out,
            )

    Run(defs).scan(rule, data["events"][:step], capture)
    return record


def formatted(source, modules):
    compile_source(source, modules)
    blocks = []
    lines = []

    def flush():
        if not lines:
            return
        if lines[0].split()[0] == "example":
            blocks.append(
                " ".join(lines[0].split())
                + "\n"
                + json.dumps(
                    json_value(lines[1]), ensure_ascii=True, separators=(",", ":")
                )
            )
        else:
            output = []
            for line in lines:
                parts = []
                prev = ""
                for token in lex(line, 1):
                    word = token.word
                    gap = (
                        parts and prev not in ("(", "=") and word not in (")", ",", "=")
                    )
                    parts.append((" " if gap else "") + word)
                    prev = word
                output.append("".join(parts))
            blocks.append("\n".join(output))
        lines.clear()

    for line in source.splitlines():
        if line.strip():
            lines.append(line)
        else:
            flush()
    flush()
    result = "\n\n".join(blocks) + "\n"
    compile_source(result, modules)
    return result


def replaced(source, defs, edits, filename):
    require(
        isinstance(edits, list) and edits and len(edits) <= 256,
        "E_EDIT",
        "Supply 1..256 edits",
    )
    index = {node_id(n): (n, env, d) for d in defs.values() for n, env in locals_at(d)}
    offsets = [0]
    for line in source.splitlines(keepends=True):
        offsets.append(offsets[-1] + len(line))

    def offset(t):
        return offsets[t.line - 1] + t.col - 1

    changes = []
    for edit in edits:
        require(
            isinstance(edit, dict)
            and set(edit) in ({"node", "op"}, {"node", "replace"})
            and isinstance(edit["node"], str),
            "E_EDIT",
            "Expected node and op or replace",
        )
        item = index.get(edit["node"])
        require(item, "E_NODE", "Unknown node: " + edit["node"])
        node, env, owner = item
        require(
            node.at.file == filename, "E_EDIT", "Node belongs to another source file"
        )
        if "op" in edit:
            text = edit["op"]
            require(
                isinstance(text, str)
                and (text in CATALOG or text in defs)
                and node.op not in ("lit", "var"),
                "E_EDIT",
                "Expected a known call operator",
            )
            start = end = node.at
            compact = render(node, False)
            _, _, rest = compact.partition(" ")
            replacement = text + (" " + rest if rest else "")
        else:
            text = edit["replace"]
            require(
                isinstance(text, str) and text.strip() and text.splitlines() == [text],
                "E_EDIT",
                "Expected one expression on a single line",
            )
            replacement = text
            start, end = node.start, node.end
        if node.typ.startswith("#"):
            require(
                env.get(replacement, "").startswith("#"),
                "E_TYPE",
                "Expected bound diagnostic",
            )
        else:
            scratch = copy(owner)
            scratch.calls = set()
            Parser(lex(replacement, 1), defs, scratch, node.at).full(env)
        changes.append((offset(start), offset(end) + len(end.word), text))
    bound = len(source)
    for lo, hi, text in sorted(changes, reverse=True):
        require(hi <= bound, "E_EDIT", "Overlapping edits")
        source = source[:lo] + text + source[hi:]
        bound = lo
    return source


def checked_edit(path, base, edits, full, write, allow_examples):
    path = Path(path).resolve()
    # Serialize TIDE writers on the directory inode, which survives file replacement.
    fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX)
        source, modules = project(path)
        original_revision = project_revision(source, modules)
        require(
            original_revision == base,
            "E_REVISION",
            "Source changed",
            actual=original_revision,
        )
        defs, original = compile_source(source, modules)
        target = path
        if full is not None:
            candidate = load(full)
            newsource, newmodules = project(path, candidate)
        else:
            require(
                isinstance(edits, list)
                and edits
                and all(
                    isinstance(e, dict) and isinstance(e.get("node"), str)
                    for e in edits
                ),
                "E_EDIT",
                "Expected edits with node identifiers",
            )
            files = {
                e["node"].rsplit(":", 2)[0] if e["node"].count(":") == 2 else None
                for e in edits
            }
            require(len(files) == 1, "E_EDIT", "One source file per atomic edit")
            filename = files.pop()
            require(filename is None or filename in modules, "E_NODE", "Unknown module")
            candidate = replaced(
                source if filename is None else modules[filename], defs, edits, filename
            )
            newsource = candidate if filename is None else source
            newmodules = (
                modules if filename is None else {**modules, filename: candidate}
            )
            if filename:
                target = path.parent / filename
        require(
            len(newsource.encode()) + sum(len(v.encode()) for v in newmodules.values())
            <= MAX_SOURCE,
            "E_LIMIT",
            "Project source size limit",
        )
        newdefs, updated = compile_source(newsource, newmodules)

        def table(examples):
            return {n: {"target": t, **data} for n, t, data, _ in examples}

        old, new = table(original), table(updated)
        # JSON distinguishes true and 1 even when a signature changes.
        diff = [
            {"example": key, "before": old.get(key), "after": new.get(key)}
            for key in sorted(old.keys() | new.keys())
            if json.dumps(old.get(key), sort_keys=True)
            != json.dumps(new.get(key), sort_keys=True)
        ]
        require(
            not any(row["before"] is not None for row in diff) or allow_examples,
            "E_CONTRACT",
            "Changed or deleted examples require --change-examples",
            changes=diff,
        )
        tests = test_examples(newdefs, updated)
        result = {
            "base": base,
            "revision": project_revision(newsource, newmodules),
            "target": target.name,
            "examples": tests,
            "contract_changes": diff,
            "written": write,
        }
        if not write:
            result["source"] = candidate
            return result
        with tempfile.NamedTemporaryFile(dir=path.parent, delete=False) as temp:
            tmp = Path(temp.name)
            try:
                temp.write(candidate.encode())
                temp.flush()
                os.fchmod(temp.fileno(), stat.S_IMODE(target.stat().st_mode))
                os.fsync(temp.fileno())
                require(
                    project_revision(*project(path)) == base,
                    "E_REVISION",
                    "Source changed during edit",
                )
                os.replace(tmp, target)
                os.fsync(fd)
            finally:
                tmp.unlink(missing_ok=True)
        return result
    finally:
        os.close(fd)


def project(path, entry=None):
    """Resolve explicit sibling TIDE modules; a diamond import loads a unit only once."""
    path = Path(path).resolve()
    source = load(path) if entry is None else entry
    modules = {}
    total = len(source.encode())
    require(total <= MAX_SOURCE, "E_LIMIT", "Project source size limit")

    def visit(filename, unit, ancestors):
        nonlocal total
        for n, line in enumerate(unit.splitlines(), 1):
            words = line.split()
            if not words or words[0] != "use":
                continue
            at = Token("use", n, len(line) - len(line.lstrip()) + 1, filename)
            require(
                len(words) == 2 and re.fullmatch(r"[A-Za-z][A-Za-z0-9_]*", words[1]),
                "E_MODULE",
                "Expected sibling module name",
                at,
            )
            key = words[1] + ".tide"
            require(
                key not in ancestors,
                "E_CYCLE",
                "Cyclic module import",
                at,
                chain=[*ancestors, key],
            )
            if key in modules:
                continue
            require(
                len(ancestors) < 32 and len(modules) < 64,
                "E_LIMIT",
                "Module count or depth limit",
                at,
            )
            sub = load(path.parent / key, no_follow=True)
            total += len(sub.encode())
            require(total <= MAX_SOURCE, "E_LIMIT", "Project source size limit", at)
            modules[key] = sub
            visit(key, sub, (*ancestors, key))

    visit(None, source, (path.name,))
    return source, modules


def project_revision(source, modules):
    if not modules:
        return revision(source)
    return revision(
        json.dumps(
            [source, sorted(modules.items())], ensure_ascii=True, separators=(",", ":")
        )
    )
