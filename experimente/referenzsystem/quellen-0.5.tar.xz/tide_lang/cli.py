"""TIDE command line. All program and workbench results are machine-readable."""

import argparse
import json
import os
import stat
import sys
from contextlib import ExitStack

from .analysis import info
from .catalog import CATALOG, GUIDE, VERSION, identity
from .core import Error, require
from .program import compile_source, json_value, validate_args
from .runtime import Run, test_examples
from .values import Grant
from .workbench import (
    check_lock,
    checked_edit,
    context,
    formatted,
    project,
    project_revision,
    trace,
)


def bindings(d, raw, reads, stack):
    args = json_value(raw)
    require(isinstance(args, dict), "E_INPUT", "Named JSON inputs required")
    paths = {}
    for entry in reads:
        name, sep, path = entry.partition("=")
        require(
            sep and path and name not in paths,
            "E_CAPABILITY",
            "Invalid or duplicate read binding",
        )
        paths[name] = path
    required = {k for k, t in d.params.items() if t == "r"}
    require(
        required == paths.keys() and not required.intersection(args),
        "E_CAPABILITY",
        "Supply the declared read grants separately",
        required=sorted(required),
    )
    args.update({k: Grant(None) for k in required})
    validate_args(d, args, d.at)
    for k, path in paths.items():
        fd = os.open(path, os.O_RDONLY | getattr(os, "O_NONBLOCK", 0))
        stack.callback(os.close, fd)
        require(
            stat.S_ISREG(os.fstat(fd).st_mode),
            "E_CAPABILITY",
            "A grant must name a regular file",
            d.at,
        )
        args[k] = Grant(stack.enter_context(os.fdopen(fd, "rb", closefd=False)))
    return args


def parser():
    root = argparse.ArgumentParser(
        prog="tide", description="Typed Instructions, Deterministic Execution"
    )
    root.add_argument("--version", action="version", version="TIDE " + VERSION)
    commands = root.add_subparsers(dest="action", required=True)
    for cmd in (
        "check",
        "test",
        "run",
        "play",
        "context",
        "hole",
        "trace",
        "edit",
        "fmt",
        "describe",
        "lock",
    ):
        p = commands.add_parser(cmd)
        if cmd not in ("describe", "lock"):
            p.add_argument("file")
        if cmd not in ("fmt", "play"):
            p.add_argument("--json", action="store_true", help="JSON output (default)")
        if cmd == "describe":
            p.add_argument("operation", nargs="?")
            p.add_argument("--project", help="verify the lock next to this source file")
        if cmd in ("context", "hole"):
            p.add_argument("--function", required=True)
            p.add_argument(
                "--node", required=cmd == "hole", help="revision-local line:column"
            )
        if cmd == "edit":
            p.add_argument("--base", required=True)
            choices = p.add_mutually_exclusive_group(required=True)
            choices.add_argument(
                "--edits",
                help='JSON array of {"node":...,"op":...} or {"node":...,"replace":...}',
            )
            choices.add_argument(
                "--source", help="complete candidate file for coordinated changes"
            )
            p.add_argument("--write", action="store_true")
            p.add_argument("--change-examples", action="store_true")
        if cmd == "trace":
            p.add_argument("--example", required=True)
            p.add_argument("--step", required=True, type=int)
            p.add_argument("--fields", help="comma-separated state fields")
        if cmd == "run":
            p.add_argument("--call", default="main", metavar="FUNCTION")
            p.add_argument("--inputs", default="{}", metavar="JSON")
            p.add_argument("--read", action="append", default=[], metavar="NAME=PATH")
        if cmd == "play":
            p.add_argument(
                "--document",
                metavar="PATH",
                help="open one UTF-8 document for interactive editing",
            )
    return root


def execute(opt):
    if opt.action == "lock":
        return identity()
    if opt.action == "describe":
        if opt.project:
            check_lock(opt.project)
        if opt.operation is None:
            return {**identity(), "operations": sorted(CATALOG), "guide": GUIDE}
        require(
            opt.operation in CATALOG, "E_NAME", "Unknown operation: " + opt.operation
        )
        return {**identity(), **CATALOG[opt.operation]}
    check_lock(opt.file)
    if opt.action == "edit":
        return checked_edit(
            opt.file,
            opt.base,
            json_value(opt.edits) if opt.edits else None,
            opt.source,
            opt.write,
            opt.change_examples,
        )
    source, modules = project(opt.file)
    if opt.action == "fmt":
        return formatted(source, modules)
    rev = project_revision(source, modules)
    defs, examples = compile_source(source, modules)
    if opt.action == "hole":
        selected = context(defs, examples, rev, opt.function, opt.node)["selection"]
        return {
            "revision": rev,
            "definition": opt.function,
            "expected_type": selected["expected_type"],
            "bindings": selected["bindings"],
            "read_grants": selected["read_grants"],
            "records": defs.records,
            "variants": defs.variants,
            "draft_edit": {"node": opt.node, "replace": "__hole__"},
        }
    if opt.action == "play":
        if opt.document is not None:
            from .document import edit_document

            return edit_document(defs, opt.document)
        from .terminal import play

        return play(defs)
    if opt.action == "context":
        return context(defs, examples, rev, opt.function, opt.node)
    if opt.action == "trace":
        return trace(defs, examples, opt.example, opt.step, opt.fields)
    if opt.action == "check":
        return {
            "tool": "TIDE " + VERSION,
            "version": identity(),
            "revision": rev,
            "modules": list(modules),
            "records": defs.records,
            "variants": defs.variants,
            "definitions": {name: info(d) for name, d in defs.items()},
            "examples": len(examples),
        }
    if opt.action == "test":
        return test_examples(defs, examples)
    d = defs.get(opt.call)
    require(d and not d.rule, "E_ENTRY", "Expected function: " + opt.call)
    with ExitStack() as stack:
        args = bindings(d, opt.inputs, opt.read, stack)
        return Run(defs).eval(d.body, args)


def main():
    opt = parser().parse_args()
    try:
        result = execute(opt)
        if opt.action == "play":
            return 0
        if opt.action == "fmt":
            sys.stdout.write(result)
        else:
            print(json.dumps(result, ensure_ascii=True, allow_nan=False))
        return 0
    except Error as e:
        detail = e.data
        for issue in detail.get("diagnostics", []):
            issue.setdefault("file", opt.file)
    except OSError as e:
        detail = {"code": "E_IO", "message": str(e)}
    except RecursionError:
        detail = {"code": "E_LIMIT", "message": "Host stack limit"}
    print(
        json.dumps({"file": getattr(opt, "file", None), **detail}, ensure_ascii=True),
        file=sys.stderr,
    )
    return 1
