"""Prefix types, JSON values and first-class read capabilities."""

import re
from dataclasses import dataclass
from functools import lru_cache

MIN, MAX = -(1 << 63), (1 << 63) - 1
MAX_ITEMS, MAX_STEPS, MAX_SOURCE = 4096, 100_000, 128 * 1024
MAX_MEMORY = 4 * 1024 * 1024


def type_end(typ, pos=0, depth=0):
    if pos >= len(typ) or depth >= 16:
        return -1
    op = typ[pos]
    if op in "ibt":
        return pos + 1
    if op == "{":
        m = re.match(r"\{[A-Za-z][A-Za-z0-9_]*\}", typ[pos:])
        return pos + m.end() if m else -1
    if op in "?*&":
        end = type_end(typ, pos + 1, depth + 1)
        if end >= 0 and op == "&":
            end = type_end(typ, end, depth + 1)
        return end
    return -1


@lru_cache(maxsize=512)
def data_type(typ):
    return 0 < len(typ) <= 128 and type_end(typ) == len(typ)


def components(typ):
    split = type_end(typ, 1)
    return typ[1:split], typ[split:]


def valid_text(value):
    return isinstance(value, str) and re.search(r"[\ud800-\udfff]", value) is None


def named_types(typ):
    return re.findall(r"\{([A-Za-z][A-Za-z0-9_]*)\}", typ)


def wire(value, typ, types=None):
    if typ == "b":
        return type(value) is bool
    if typ == "i":
        return type(value) is int and MIN <= value <= MAX
    if typ == "t":
        return valid_text(value)
    if typ.startswith("{"):
        fields = (types or {}).get(typ[1:-1])
        if isinstance(fields, frozenset):
            return isinstance(value, str) and value in fields
        return (
            fields is not None
            and isinstance(value, dict)
            and value.keys() == fields.keys()
            and all(wire(value[k], t, types) for k, t in fields.items())
        )
    if typ.startswith("?"):
        return isinstance(value, dict) and (
            (set(value) == {"none"} and value["none"] is True)
            or (set(value) == {"some"} and wire(value["some"], typ[1:], types))
        )
    if not isinstance(value, list):
        return False
    if typ.startswith("&"):
        return len(value) == 2 and all(
            wire(v, t, types) for v, t in zip(value, components(typ))
        )
    return (
        typ.startswith("*")
        and len(value) <= MAX_ITEMS
        and all(wire(v, typ[1:], types) for v in value)
    )


@dataclass
class Grant:
    # Only the host constructs a grant. Examples bind in-memory bytes.
    handle: object
    snapshot: bytes | None = None


def integer(text):
    if not re.fullmatch(r"-?[0-9]+", text):
        return None
    digits = text.lstrip("-").lstrip("0") or "0"
    if len(digits) > 19:
        return None
    n = int(digits) * (-1 if text.startswith("-") else 1)
    return n if MIN <= n <= MAX else None


def option(value):
    return {"none": True} if value is None else {"some": value}
