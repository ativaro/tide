"""Compile and check an entire TIDE file before evaluating any declaration."""

import json
from dataclasses import dataclass, field

from .catalog import CATCHABLE
from .core import (
    Error,
    Parser,
    Token,
    binding,
    check_type,
    lex,
    require,
)
from .values import MAX_SOURCE, Grant, data_type, named_types, valid_text, wire


def json_value(text, at=None):
    require(valid_text(text), "E_UTF8", "Invalid Unicode in JSON input", at)
    require(len(text.encode("utf-8")) <= MAX_SOURCE, "E_LIMIT", "JSON size limit", at)

    def unique(pairs):
        obj = dict(pairs)
        if len(obj) != len(pairs):
            raise ValueError("Duplicate JSON key")
        return obj

    def constant(_):
        raise ValueError("Invalid JSON constant")

    try:
        return json.loads(text, object_pairs_hook=unique, parse_constant=constant)
    except (ValueError, RecursionError) as e:
        raise Error("E_JSON", "Invalid JSON: " + str(e), at) from None


class Definitions(dict):
    def __init__(self):
        super().__init__()
        self.types = {}

    @property
    def records(self):
        return {k: v for k, v in self.types.items() if isinstance(v, dict)}

    @property
    def variants(self):
        return {k: sorted(v) for k, v in self.types.items() if isinstance(v, frozenset)}


@dataclass
class Definition:
    name: str
    params: dict
    ret: str
    rule: bool
    at: Token
    types: dict = field(default_factory=dict)
    calls: set = field(default_factory=set)
    body: object = None
    starts: dict = field(default_factory=dict)
    rows: list = field(default_factory=list)


def declare(token):
    name, sep, typ = token.word.partition(":")
    require(
        sep and (typ == "r" or data_type(typ)), "E_TYPE", "Expected name:type", token
    )
    return name, typ


def cut(tokens, marker, at):
    for i, t in enumerate(tokens):
        if t.word == marker:
            return tokens[:i], tokens[i + 1 :]
    raise Error("E_SYNTAX", "Missing " + marker, at)


def expression(tokens, defs, d, scope, typ=None):
    value = Parser(tokens, defs, d, d.at).full(scope)
    if typ:
        check_type(value.typ, typ, value.at)
        value.expected = typ
    return value


def compile_rule(d, lines, defs):
    require(
        len(lines) >= 3 and lines[0][0].word == "state" and lines[-1][0].word == "out",
        "E_SYNTAX",
        "Expected state, branches and out",
        d.at,
    )
    fields = {}
    decls = lines[0][1:]
    require(
        decls and len(decls) % 3 == 0,
        "E_SYNTAX",
        "Expected name:type=start entries",
        lines[0][0],
    )
    for i in range(0, len(decls), 3):
        entry, assign, value = decls[i : i + 3]
        name, typ = declare(entry)
        binding(name, defs.keys() | d.params.keys() | fields.keys(), entry)
        require(
            typ in ("i", "b") and assign.word == "=",
            "E_TYPE",
            "Expected scalar state initializer",
            entry,
        )
        d.starts[name] = expression([value], defs, d, {}, typ)
        fields[name] = typ
    scope = d.params | fields
    for row in lines[1:-1]:
        head, terms = cut(row, "->", row[0])
        require(
            head and (not d.rows or d.rows[-1][0] is not None),
            "E_SYNTAX",
            "Invalid or unreachable branch",
            row[0],
        )
        if head[0].word == "when":
            guard = expression(head[1:], defs, d, scope, "b")
        else:
            require(
                [t.word for t in head] == ["else"],
                "E_SYNTAX",
                "Expected when or else",
                row[0],
            )
            guard = None
        groups = [[]]
        for tok in terms:
            if tok.word == ",":
                groups.append([])
            else:
                groups[-1].append(tok)
        actions = {}
        for group in groups:
            require(
                len(group) >= 3 and group[1].word == "=",
                "E_SYNTAX",
                "Expected field=action",
                row[0],
            )
            key, op = group[0].word, group[2].word
            require(
                key in fields and key not in actions,
                "E_NAME",
                "Unknown or duplicate state field",
                group[0],
            )
            if op == "set":
                actions[key] = expression(group[3:], defs, d, scope, fields[key])
            else:
                require(
                    len(group) == 3 and op in ("reset", "keep"),
                    "E_SYNTAX",
                    "Unknown state action",
                    group[2],
                )
                actions[key] = op
        require(
            actions.keys() == fields.keys(),
            "E_TYPE",
            "Branch must assign every field",
            head[0],
        )
        d.rows.append((guard, actions))
    require(d.rows and d.rows[-1][0] is None, "E_SYNTAX", "Missing final else", d.at)
    d.body = expression(lines[-1][1:], defs, d, scope, d.ret)


def validate_args(definition, args, at=None, *, example=False):
    require(
        isinstance(args, dict) and args.keys() == definition.params.keys(),
        "E_INPUT",
        "Expected exactly the declared parameters",
        at,
        expected=list(definition.params),
    )
    for key, typ in definition.params.items():
        require(
            (valid_text(args[key]) if example else isinstance(args[key], Grant))
            if typ == "r"
            else wire(args[key], typ, definition.types),
            "E_INPUT",
            "Invalid argument " + key,
            at,
            expected=typ,
        )


def example_schema(example, d, at):
    require(isinstance(example, dict), "E_EXAMPLE", "Expected JSON object", at)
    inp = "events" if d.rule else "inputs"
    out = "expect_error" if "expect_error" in example else "expect"
    require(set(example) == {inp, out}, "E_EXAMPLE", "Invalid example keys", at)
    if d.rule:
        events = example[inp]
        require(
            wire(events, "*" + next(iter(d.params.values())), d.types),
            "E_INPUT",
            "Invalid events",
            at,
        )
    else:
        validate_args(d, example[inp], at, example=True)
    if out == "expect_error":
        err = example[out]
        require(
            isinstance(err, dict)
            and err.keys() <= {"code", "reason", "input_line"}
            and err.get("code") in (*CATCHABLE, "E_LIMIT", "E_CAPABILITY")
            and ("input_line" not in err or wire(err["input_line"], "i"))
            and ("reason" not in err or isinstance(err["reason"], str)),
            "E_EXAMPLE",
            "Invalid expected error",
            at,
        )
    else:
        expected = example[out]
        require(
            wire(expected, ("*" if d.rule else "") + d.ret, d.types),
            "E_EXAMPLE",
            "Invalid expected value",
            at,
        )
        if d.rule:
            require(
                len(expected) == len(events),
                "E_EXAMPLE",
                "One output per event required",
                at,
            )


def compile_source(source, modules=None):
    blocks = []
    for filename, unit in [(None, source), *(modules or {}).items()]:
        part = []
        for n, line in enumerate(unit.splitlines(), 1):
            if line.strip():
                part.append((n, line))
            elif part:
                blocks.append((filename, part))
                part = []
        if part:
            blocks.append((filename, part))
    require(blocks, "E_SYNTAX", "Empty program", Token("", 1, 1))
    defs, bodies, examples, names = Definitions(), {}, [], set()
    record_sites = {}
    for filename, ((n, header), *rows) in blocks:
        words = lex(header, n, filename)
        at = words[0]
        if at.word == "use":
            require(
                not rows
                and len(words) == 2
                and modules is not None
                and words[1].word + ".tide" in modules,
                "E_MODULE",
                "Invalid or unresolved use declaration",
                at,
            )
            continue
        require(rows, "E_SYNTAX", "Missing declaration body", at)
        if at.word in ("record", "variant"):
            require(len(words) == 2, "E_SYNTAX", "Expected type name", at)
            name = words[1].word
            binding(name, defs.keys() | defs.types.keys(), words[1])
            if at.word == "variant":
                tags = set()
                for num, line in rows:
                    for tag in lex(line, num, filename):
                        binding(tag.word, tags, tag)
                        tags.add(tag.word)
                defs.types[name] = frozenset(tags)
                continue
            fields = {}
            for num, line in rows:
                for field_token in lex(line, num, filename):
                    key, typ = declare(field_token)
                    binding(key, fields, field_token)
                    require(
                        data_type(typ),
                        "E_TYPE",
                        "Record fields must be data",
                        field_token,
                    )
                    fields[key] = typ
            defs.types[name] = fields
            record_sites[name] = at
            continue
        if at.word == "example":
            require(
                len(words) == 3 and len(rows) == 1,
                "E_SYNTAX",
                "Expected example name target and JSON",
                at,
            )
            name, target = words[1:]
            binding(name.word, names, name)
            names.add(name.word)
            num, text = rows[0]
            examples.append(
                (
                    name.word,
                    target.word,
                    json_value(text, Token("", num, 1, filename)),
                    at,
                )
            )
            continue
        rule = at.word == "rule"
        left, right = cut(words[1:] if rule else words, ">", at)
        require(
            left and len(right) == 1 and data_type(right[0].word),
            "E_SYNTAX",
            "Invalid signature",
            at,
        )
        name = left[0].word
        binding(name, defs.keys() | defs.types.keys(), left[0])
        params = {}
        for token in left[1:]:
            param, typ = declare(token)
            binding(param, params, token)
            params[param] = typ
        if rule:
            require(
                len(params) == 1
                and data_type(next(iter(params.values())))
                and data_type("*" + right[0].word),
                "E_TYPE",
                "Rule needs one event and a scalar or pair result",
                at,
            )
        defs[name] = Definition(name, params, right[0].word, rule, at, defs.types)
        bodies[name] = [lex(line, num, filename) for num, line in rows]
    checked = {}

    def record_depth(name, path):
        require(
            name in defs.types,
            "E_TYPE",
            "Unknown named type: " + name,
            record_sites[path[-1]] if path else None,
        )
        if isinstance(defs.types[name], frozenset):
            return 0
        require(
            name not in path and len(path) < 16,
            "E_TYPE",
            "Cyclic or deeply nested record",
            record_sites[name],
        )
        if name not in checked:
            checked[name] = 1 + max(
                (
                    record_depth(n, (*path, name))
                    for t in defs.types[name].values()
                    for n in named_types(t)
                ),
                default=0,
            )
        return checked[name]

    for name, site in record_sites.items():
        require(
            record_depth(name, ()) <= 16,
            "E_TYPE",
            "Record nesting limit",
            site,
        )
    for name, d in defs.items():
        for typ in (*d.params.values(), d.ret):
            require(
                all(n in defs.types for n in named_types(typ)),
                "E_TYPE",
                "Unknown named type in signature",
                d.at,
            )
        for param in d.params:
            binding(param, defs, d.at)
        lines = bodies[name]
        if d.rule:
            compile_rule(d, lines, defs)
        else:
            d.body = expression(
                [t for row in lines for t in row], defs, d, d.params, d.ret
            )
    depths = {}

    def depth(name, path):
        require(
            name not in path,
            "E_CYCLE",
            "Recursive call: " + " -> ".join((*path, name)),
            defs[name].at,
        )
        require(len(path) < 48, "E_LIMIT", "Call depth limit", defs[name].at)
        if name not in depths:
            depths[name] = 1 + max(
                (depth(k, (*path, name)) for k in sorted(defs[name].calls)), default=0
            )
        return depths[name]

    for name, definition in defs.items():
        require(depth(name, ()) <= 48, "E_LIMIT", "Call depth limit", definition.at)
    from .analysis import analyze

    analyze(defs)
    for _, target, data, at in examples:
        require(target in defs, "E_NAME", "Unknown example target: " + target, at)
        example_schema(data, defs[target], at)
    return defs, examples
