"""The machine-readable vocabulary shared by the parser and the programming tools."""

import hashlib
import json

VERSION = "0.5.0"
LANGUAGE = "0.5"
CATCHABLE = ("E_DATA", "E_OVERFLOW", "E_UTF8", "E_IO")
# Syntax, result, executable expression, free parameters, possible local errors.
_ROWS = [
    ("+", "+ i i", "i", "+ 7 2", "", ["E_OVERFLOW"]),
    ("-", "- i i", "i", "- 7 2", "", ["E_OVERFLOW"]),
    ("*", "* i i", "i", "* 7 2", "", ["E_OVERFLOW"]),
    ("div", "div i i", "i", "div -7 2", "", ["E_DATA", "E_OVERFLOW"]),
    ("mod", "mod i i", "i", "mod -7 2", "", ["E_DATA"]),
    ("<", "< i i", "b", "< 1 2", "", []),
    (">", "> i i", "b", "> 2 1", "", []),
    ("eq", "eq i i", "b", "eq 2 2", "", []),
    ("not", "not b", "b", "not false", "", []),
    ("and", "and b b", "b", "and true false", "", []),
    ("or", "or b b", "b", "or true false", "", []),
    ("if", "if b A A", "A", "if true 5 0", "", []),
    ("let", "let name A body:B", "B", "let x 5 + x 1", "", []),
    ("pair", "pair A B", "&AB", "pair 1 true", "", []),
    ("first", "first &AB", "A", "first pair 4 false", "", []),
    ("second", "second &AB", "B", "second pair 4 false", "", []),
    ("list", "list Type N A...", "*A", "list i 2 7 8", "", []),
    (
        "tag",
        "tag Variant label",
        "{Variant}",
        "tag Signal green",
        "variant Signal / red green",
        [],
    ),
    (
        "match",
        "match {Variant} label A ... end",
        "A",
        "match tag Signal green red 0 green 1 end",
        "variant Signal / red green",
        [],
    ),
    (
        "make",
        "make Record field A ...",
        "{Record}",
        "make Sample value 7",
        "record Sample / value:i",
        [],
    ),
    ("get", "get field {Record}", "A", "get value sample", "sample:{Sample}", []),
    (
        "with",
        "with field {Record} A",
        "{Record}",
        "with value sample 8",
        "sample:{Sample}",
        [],
    ),
    (
        "fold",
        "fold *A B accumulator row element body:B",
        "B",
        "fold list i 2 3 4 0 acc row x + acc x",
        "",
        [],
    ),
    (
        "scan",
        "scan rule *A",
        "*B",
        "scan pump list i 2 19 81",
        "rule pump level:i > b",
        [],
    ),
    ("nil", "nil Type", "?A", "nil i", "", []),
    ("some", "some A", "?A", "some 8", "", []),
    ("case", "case ?A empty:B name full:B", "B", "case some 8 0 x + x 1", "", []),
    ("need", "need ?A reason:t row:i", "A", 'need some 8 "missing" 2', "", ["E_DATA"]),
    ("int", "int t", "?i", 'int "-20"', "", []),
    ("lines", "lines t", "*t", 'lines "a\\nb"', "", []),
    ("read", "read r", "t", "read input", "input:r", ["E_IO", "E_UTF8"]),
    ("concat", "concat t t", "t", 'concat "ab" "cd"', "", []),
    ("text_len", "text_len t", "i", 'text_len "aΩ"', "", []),
    ("text_slice", "text_slice t start:i stop:i", "t", 'text_slice "aΩb" 1 2', "", []),
    (
        "text_find",
        "text_find t needle:t start:i",
        "?i",
        'text_find "abcab" "ab" 1',
        "",
        [],
    ),
    (
        "text_rfind",
        "text_rfind t needle:t stop:i",
        "?i",
        'text_rfind "abcab" "ab" 4',
        "",
        [],
    ),
    ("text_eq", "text_eq t t", "b", 'text_eq "a" "b"', "", []),
    ("length", "length *A", "i", "length list i 0", "", []),
    ("at", "at *A index:i", "?A", "at list i 2 3 4 1", "", []),
    ("append", "append *A A", "*A", "append list i 1 3 4", "", []),
    (
        "catch",
        "catch CODE body:A errorName replacement:A",
        "A",
        'catch E_DATA fail "bad" _ 7',
        "",
        [],
    ),
    ("fail", "fail reason:t", "never", 'fail "bad"', "", ["E_DATA"]),
    (
        "input_line",
        "input_line errorName",
        "?i",
        'catch E_DATA need nil i "bad" 3 e case input_line e 0 n n',
        "",
        [],
    ),
    (
        "has_reason",
        "has_reason errorName t",
        "b",
        'catch E_DATA fail "bad" e has_reason e "bad"',
        "",
        [],
    ),
    ("raise", "raise errorName", "never", 'catch E_DATA fail "bad" e raise e', "", []),
]
CATALOG = {
    name: {
        "operation": name,
        "syntax": syntax,
        "returns": ret,
        "example": expr,
        "requires": params,
        "effect": "read" if name == "read" else "pure",
        "may_fail": codes,
        "arity": "2+N"
        if name == "list"
        else "1+2*Nfields"
        if name == "make"
        else "2+2*Ntags"
        if name == "match"
        else len(syntax.split()) - 1,
    }
    for name, syntax, ret, expr, params, codes in _ROWS
}


def identity():
    data = json.dumps(CATALOG, sort_keys=True, separators=(",", ":")).encode()
    return {
        "language": LANGUAGE,
        "tool": VERSION,
        "catalog_sha256": hashlib.sha256(data).hexdigest(),
    }


NOTES = {
    "text_len": "Length in Unicode code points.",
    "text_slice": "Zero-based half-open code-point range. Clamp bounds to the text. Reversed bounds give empty text.",
    "text_find": "First match in [start,length), returning its absolute code-point offset or none. Clamp start.",
    "text_rfind": "Last match in [0,stop), returning its absolute code-point offset or none. Clamp stop.",
    "tag": "Create a value of the named variant type. The label must be declared.",
    "match": "Give one branch per declared tag in any order. End with end. Evaluate the subject once and only its selected branch.",
    "if": "Evaluate only the selected branch.",
    "and": "Short-circuit on false.",
    "or": "Short-circuit on true.",
    "div": "Signed integer division truncates toward zero. Zero divisor has reason division_by_zero.",
    "mod": "Remainder has the dividend's sign. Zero divisor has reason division_by_zero.",
    "int": "Parse ASCII decimal i64 with optional minus. Whitespace, empty input and range errors yield none.",
    "lines": "Split on LF or CRLF. Keep embedded empty lines. A final separator adds no extra line.",
    "read": "Read the UTF-8 snapshot of a host-supplied regular-file grant. Paths are not language values for this operation.",
    "case": "Compute empty only for none; bind name and evaluate full only for some.",
    "need": "For none evaluate reason then row and raise E_DATA. For some return the payload without evaluating either.",
    "catch": "Intercept only CODE. Bind its diagnostic in replacement; _ discards it. Replacement errors propagate.",
    "raise": "Rethrow the bound diagnostic, preserving original source and input line.",
    "at": "Zero-based indexing. A negative or out-of-bounds index returns none.",
    "fold": "Left fold in input order. Bind the accumulator, one-based row and element. Empty list returns start.",
    "scan": "Run the named rule with fresh initial state. Return one value per input event in order.",
    "make": "Supply every field in declaration order, spelling its name before its value.",
    "with": "Return a copy of the record with the named field replaced.",
    "let": "Immutable binding. Shadowing is rejected.",
}
for name, note in NOTES.items():
    CATALOG[name]["semantics"] = note

GUIDE = {
    "entry": "main; separate declarations with blank lines; prefix calls, optional grouping; UTF-8 source",
    "definitions": [
        "name arg:Type > Type / expression",
        "use sibling_module",
        "record Name / field:Type ...",
        "variant Name / label ...",
        "rule name event:Type > Type / state x:i=0 / when b -> x=set i / else -> x=keep / out x",
        'example id function / {"inputs":{...},"expect":...}',
    ],
    "types": {
        "i": "signed i64",
        "b": "boolean",
        "t": "UTF-8 text",
        "r": "host read grant; parameter only",
        "?A": '{"none":true} or {"some":value}',
        "*A": "JSON list",
        "&AB": "JSON pair [a,b]",
        "{Name}": "named record (JSON object) or named variant (declared JSON string tag)",
    },
    "workflow": [
        "describe OP",
        "check FILE",
        "context FILE --function NAME [--node ID]",
        "test FILE",
        "edit FILE --base REV --edits JSON [--write]",
        "run FILE [--inputs JSON] [--read NAME=PATH]",
    ],
}
