"""Event-driven terminal host with a single user-selected document."""

import curses
import fcntl
import os
import stat
import sys
import tempfile
import unicodedata
from pathlib import Path

from .core import Error, require
from .runtime import Run
from .values import MAX_SOURCE
from .workbench import load


def version(path):
    try:
        info = path.lstat()
    except FileNotFoundError:
        return None
    require(stat.S_ISREG(info.st_mode), "E_IO", "Reguläre Datei erforderlich")
    return info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns


class Document:
    def __init__(self, path):
        self.path = Path(path)
        self.version = version(self.path)
        self.body = load(self.path, no_follow=True) if self.version is not None else ""
        self.check_version()

    def check_version(self):
        require(
            version(self.path) == self.version,
            "E_REVISION",
            "Datei wurde extern geändert",
        )

    def save(self, body):
        raw = body.encode("utf-8")
        require(len(raw) <= MAX_SOURCE, "E_LIMIT", "Datei zu groß (128 KiB)")
        directory = os.open(self.path.parent, os.O_RDONLY | os.O_DIRECTORY)
        try:
            fcntl.flock(directory, fcntl.LOCK_EX)
            self.check_version()
            if self.version is not None and body == self.body:
                return
            mode = None
            if self.version is not None:
                fd = os.open(self.path, os.O_WRONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
                try:
                    mode = os.fstat(fd).st_mode & 0o777
                finally:
                    os.close(fd)
            with tempfile.NamedTemporaryFile(dir=self.path.parent, delete=False) as tmp:
                try:
                    tmp.write(raw)
                    tmp.flush()
                    if mode is not None:
                        os.fchmod(tmp.fileno(), mode)
                    os.fsync(tmp.fileno())
                    self.check_version()
                    if self.version is None:
                        os.link(tmp.name, self.path)
                        os.unlink(tmp.name)
                    else:
                        os.replace(tmp.name, self.path)
                    self.version = version(self.path)
                    self.body = body
                    os.fsync(directory)
                finally:
                    Path(tmp.name).unlink(missing_ok=True)
        finally:
            os.close(directory)


SPECIAL = {
    curses.KEY_LEFT: "left",
    curses.KEY_RIGHT: "right",
    curses.KEY_UP: "up",
    curses.KEY_DOWN: "down",
    curses.KEY_HOME: "home_key",
    curses.KEY_END: "end_key",
    curses.KEY_DC: "delete_key",
    curses.KEY_BACKSPACE: "backspace",
    curses.KEY_ENTER: "enter_key",
    "\b": "backspace",
    "\x7f": "backspace",
    "\n": "enter_key",
    "\r": "enter_key",
    "\x1b": "escape",
}


def key_event(raw):
    if raw in SPECIAL:
        return SPECIAL[raw], ""
    if isinstance(raw, str):
        if raw == "\t" or raw.isprintable():
            return "character", raw
        if 1 <= ord(raw) <= 26:
            return "control", chr(ord("a") + ord(raw) - 1)
    return None


def check_interface(defs):
    require("main" in defs, "E_PLAY", "Missing document entry point")
    state = defs["main"].ret
    for name, params, result in (
        ("main", {"body": "t"}, state),
        (
            "step",
            {"world": state, "key": "{Input}", "value": "t"},
            "&" + state + "{Effect}",
        ),
        ("view", {"world": state, "name": "t"}, "{View}"),
    ):
        d = defs.get(name)
        require(
            d
            and not d.rule
            and not d.effects
            and d.params == params
            and d.ret == result,
            "E_PLAY",
            "Invalid document function",
            function=name,
            params=params,
            returns=result,
        )
    inputs = set(SPECIAL.values()) | {"character", "control", "stored", "io_error"}
    require(
        defs.types.get("Input") == inputs
        and defs.types.get("Effect") == {"idle", "store", "finish"},
        "E_PLAY",
        "Invalid document events or effects",
    )
    require(
        defs.records.get("View")
        == {"body": "t", "caret": "i", "title": "t", "status": "t", "help": "t"},
        "E_PLAY",
        "Invalid document view",
    )


def cell_width(char, column):
    if char == "\t":
        return 4 - column % 4
    if not char.isprintable():
        return 1
    if unicodedata.category(char) in ("Mn", "Me"):
        return 0
    return 2 if unicodedata.east_asian_width(char) in ("W", "F") else 1


def clipped(line, left, width):
    """Clip in terminal cells without cutting a tab or drawing half a wide glyph."""
    result = []
    column = 0
    for char in line:
        size = cell_width(char, column)
        if column >= left + width and size:
            break
        stop = column + size
        if size == 0:
            if left < column <= left + width:
                result.append(char)
        elif stop > left:
            if char == "\t" or column < left or stop > left + width:
                result.append(" " * (min(stop, left + width) - max(column, left)))
            else:
                result.append(char if char.isprintable() else "?")
        column = stop
    return "".join(result)


def draw(screen, page, top, left, message):
    rows, cols = screen.getmaxyx()
    body, pos = page["body"], page["caret"]
    row = body.count("\n", 0, pos)
    column = 0
    for char in body[body.rfind("\n", 0, pos) + 1 : pos]:
        column += cell_width(char, column)
    height = max(0, rows - 3)
    top = max(0, row - height + 1, min(top, row)) if height else row
    left = max(0, column - cols + 1, min(left, column))
    screen.erase()

    def put(y, line, offset=0, style=0):
        if 0 <= y < rows:
            visible = clipped(line, offset, cols - int(y == rows - 1))
            if visible:
                screen.addstr(y, 0, visible, style)

    put(0, page["title"], style=curses.A_REVERSE)
    lines = body.split("\n")
    for i, line in enumerate(lines[top : top + height]):
        put(1 + i, line.removesuffix("\r") if top + i < len(lines) - 1 else line, left)
    put(rows - 2, message or page["status"] or f"Zeile {row + 1}  Spalte {column + 1}")
    put(rows - 1, page["help"], style=curses.A_REVERSE)
    if height:
        screen.move(1 + row - top, column - left)
    screen.refresh()
    return top, left


def edit_document(defs, path):
    check_interface(defs)
    require(
        sys.stdin.isatty() and sys.stdout.isatty(),
        "E_TERMINAL",
        "Interaktives Terminal erforderlich",
    )
    doc = Document(path)

    def call(function, **env):
        return Run(defs).eval(defs[function].body, env)

    def view(world):
        page = call("view", world=world, name=doc.path.name)
        require(
            0 <= page["caret"] <= len(page["body"]),
            "E_PLAY",
            "Ungültige Cursorposition",
        )
        require(
            len(page["body"].encode("utf-8")) <= MAX_SOURCE,
            "E_LIMIT",
            "Datei zu groß (128 KiB)",
        )
        return page

    def loop(screen):
        curses.raw()
        screen.keypad(True)
        curses.set_escdelay(25)
        world = call("main", body=doc.body)
        page = view(world)
        top = left = 0
        message = ""
        while True:
            top, left = draw(screen, page, top, left, message)
            event = key_event(screen.get_wch())
            if event is None:
                continue
            key, value = event
            try:
                candidate, effect = call("step", world=world, key=key, value=value)
                if effect == "store":
                    try:
                        doc.save(view(candidate)["body"])
                        key, value = "stored", ""
                    except (OSError, Error) as exc:
                        key, value = "io_error", str(exc)
                    candidate, effect = call(
                        "step", world=candidate, key=key, value=value
                    )
                    require(
                        effect != "store",
                        "E_PLAY",
                        "Repeated store in save acknowledgement",
                    )
                if effect == "finish":
                    return
                page = view(candidate)
                world, message = candidate, ""
            except Error as exc:
                message = str(exc)

    try:
        curses.wrapper(loop)
    except curses.error as exc:
        raise Error("E_TERMINAL", f"Terminal unavailable: {exc}") from None
