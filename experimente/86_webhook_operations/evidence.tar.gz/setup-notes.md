
## Setup and independent checks

The first attempt stopped at its first database restart. PostgreSQL initially received the private socket path as a start argument. A later start used its default path and failed before it could serve requests. The launcher now persists the socket directory, disabled TCP listeners and log prefix in the cluster configuration. Another startup encountered an occupied port before measurement began. The service now asks the kernel to bind an available loopback port and saves that address for subsequent restarts. Neither attempt contributes time to this qualification.

The previous binary was built from Stage 16 commit `8a268bd`. The candidate adds the database-backed `GET /ready` endpoint. Its service backend returns HTTP 503 and a retry hint when the database grant cannot be opened. Both releases use the same database schema. The deployment experiment covers a compatible upgrade. The archive records both exact binary hashes.

A separate automated operator-drill rehearsal recovered the pending request using the stored error and the persisted database configuration. It used a separate cluster and port. It contributes no human operator result.

The workstation ran TIDE 0.6.12 and PostgreSQL 18.6 on Linux 7.3.4-1-cachyos x86-64 with an AMD Ryzen 9 9950X3D. A separate preparation from the pinned revision rebuilt both binaries and passed three TIDE webhook examples. The candidate matched the timed binary byte for byte. The previous binary from the separate checkout had a different SHA-256. The timed rollback used the original archived binary and verified its identity and HTTP behavior at every switch.
